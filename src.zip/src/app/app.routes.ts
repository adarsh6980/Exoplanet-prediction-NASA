import { Routes } from '@angular/router';
// Update the import path to match the actual file name, e.g. 'home.page.ts' or 'home.component.ts'
import { HomePage } from './pages/home.page';
// Update the import path to match the actual file name, e.g. 'explore.component.ts' or 'explore.page.ts'
import { ExplorePage } from './pages/explore.page';
import { PlanetPage } from './pages/planet.page';
// Update the import path to match the actual file name, e.g. 'upload.component.ts' or 'upload.page.ts'
import { UploadPage } from './pages/upload.page';
import { DashboardPage } from './pages/dashboard.page';

export const routes: Routes = [
  { path: '', component: DashboardPage, title: 'ExoPlayground Dashboard' },
  { path: '', component: HomePage, title: 'Exoplanet Playground' },
  { path: 'explore', component: ExplorePage, title: 'Explore' },
  { path: 'planet/:id', component: PlanetPage, title: 'Planet' },
  { path: 'upload', component: UploadPage, title: 'Data Import' },
  { path: '**', redirectTo: '' },
];
