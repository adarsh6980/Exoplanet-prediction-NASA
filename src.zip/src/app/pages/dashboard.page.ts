import { Component, inject, effect } from '@angular/core';
import { NgIf, NgFor, NgSwitch, NgSwitchCase, NgSwitchDefault } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatIconModule } from '@angular/material/icon';
import { FiltersComponent } from '../components/filters.component';
import { KpiCardComponent } from '../components/kpi-card.component';
import { ChartCardComponent } from '../components/chart-card.component';
import { PlanetTableComponent, TableRow } from '../components/planet-table.component';

import { DataStoreService } from '../services/data-store.service';

type ChartType = 'scatter' | 'pie' | 'stacked' | 'line' | 'histogram' | null;

@Component({
  standalone: true,
  selector: 'app-dashboard',
  imports: [
    NgIf,
    NgFor,
    NgSwitch,
    NgSwitchCase,
    NgSwitchDefault,
    MatCardModule, 
    MatButtonToggleModule,
    MatIconModule,
    FiltersComponent, 
    KpiCardComponent, 
    ChartCardComponent, 
    PlanetTableComponent,

  ],
  template: `
  <div class="dashboard-container">
    <div class="grid">
      <div class="left"><filters-panel/></div>
      <div class="center">
      <div class="kpis">
        <kpi-card label="Planets" [value]="store.kpi().total"></kpi-card>
        <kpi-card label="Confirmed" [value]="store.kpi().confirmed"></kpi-card>
        <kpi-card label="Candidates" [value]="store.kpi().candidate"></kpi-card>
        <kpi-card label="False Positives" [value]="store.kpi().fp"></kpi-card>
      </div>
      
      <div class="divider"></div>
      
      <div class="chart-container">
        <div class="chart-nav">
          <button 
            *ngFor="let chart of chartTypes" 
            (click)="activeChart = chart.id"
            [class.active]="activeChart === chart.id"
            mat-stroked-button>
            <mat-icon>{{ chart.icon }}</mat-icon>
            {{ chart.label }}
          </button>
        </div>

        <div class="chart-wrapper" [ngSwitch]="activeChart">
          <chart-card 
            *ngSwitchCase="'scatter'" 
            title="Radius vs Period (log-log)" 
            [options]="scatterOpts"
            class="chart-card">
          </chart-card>
          
          <chart-card 
            *ngSwitchCase="'line'" 
            title="Average Radius by Period" 
            [options]="pieOpts"
            class="chart-card">
          </chart-card>
          
          <chart-card 
            *ngSwitchCase="'stacked'" 
            title="Discoveries per Year × Method" 
            [options]="stackedOpts"
            class="chart-card">
          </chart-card>
          
          <chart-card 
            *ngSwitchCase="'histogram'" 
            title="Planet Density Distribution" 
            [options]="histogramOpts"
            class="chart-card">
          </chart-card>
          
          <div *ngSwitchDefault class="no-chart">
            <p>Select a chart to display</p>
          </div>
        </div>
      </div>
    </div>
      <div class="right">
        <mat-card class="card-glass" *ngIf="store.loading()">Loading…</mat-card>
        <planet-table *ngIf="!store.loading()" [rows]="tableRows"></planet-table>
      </div>
    </div>
  </div>
  `,
  styles: [`
    :host {
      --card-bg: transparent;
      --input-bg: transparent;
      --text-color: rgba(255, 255, 255, 0.9);
      --secondary-text: rgba(255, 255, 255, 0.7);
      --border-color: rgba(255, 255, 255, 0.2);
    }
    
    .dashboard-container {
      height: 100vh;
      max-height: 100vh;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      position: relative;
      z-index: 1;
      color: white;
      text-shadow: 0 1px 2px rgba(0,0,0,0.5);
      
      /* Ensure all text is visible on video background */
      h1, h2, h3, h4, h5, h6, p, span, div, button, mat-icon {
        color: inherit;
        text-shadow: inherit;
      }
      
      /* Make sure cards are semi-transparent */
      mat-card {
        background: rgba(15, 23, 42, 0.8) !important;
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.1);
      }
      
      /* Style for buttons to be more visible */
      button {
        background: rgba(30, 41, 59, 0.8) !important;
        &:hover {
          background: rgba(51, 65, 85, 0.8) !important;
        }
      }
    }
    
    .grid {
      display: grid;
      grid-template-columns: 260px 1fr 1fr;
      grid-template-rows: auto 1fr;
      grid-template-areas: 
        "left center right";
      gap: 12px;
      padding: 8px;
      flex: 1;
      min-height: 0;
    }
    
    .left {
      grid-area: left;
      position: relative;
    }
    
    .center {
      grid-area: center;
      display: flex;
      flex-direction: column;
      min-width: 0;
      min-height: 0;
    }
    
    .right {
      grid-area: right;
      display: flex;
      flex-direction: column;
      min-width: 0;
      min-height: 0;
    }
    
    .kpis {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 16px;
      margin-bottom: 24px;
      width: 100%;
      min-width: 0; /* Allows grid to shrink below content size */
      
      kpi-card {
        min-width: 0; /* Allows cards to shrink below content size */
      }
    }
    
    .divider {
      height: 1px;
      background-color: var(--border-color, rgba(255, 255, 255, 0.2));
      margin: 0 0 24px 0;
      width: 100%;
    }
    
    .kpis kpi-card {
      background: transparent !important;
    }
    
    .chart-container {
      flex: 1;
      display: flex;
      flex-direction: column;
      min-height: 0;
      padding-top: 8px;
      background: transparent !important;
      
      .chart-nav {
        display: flex;
        gap: 8px;
        margin-bottom: 16px;
        
        button {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 0 16px;
          height: 36px;
          border-radius: 18px;
          font-size: 14px;
          font-weight: 500;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          transition: all 0.2s ease;
          background: rgba(30, 41, 59, 0.8) !important;
          color: rgba(255, 255, 255, 0.9) !important;
          border: 1px solid rgba(255, 255, 255, 0.2) !important;
          
          mat-icon {
            font-size: 18px;
            width: 18px;
            height: 18px;
            margin-right: 4px;
          }
          
          &:hover {
            background: rgba(51, 65, 85, 0.9) !important;
            transform: translateY(-1px);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
          }
          
          &:active {
            transform: translateY(0);
            box-shadow: none;
          }
          
          &.active {
            background: rgba(59, 130, 246, 0.9) !important;
            border-color: rgba(96, 165, 250, 0.8) !important;
            color: white !important;
            font-weight: 600;
          }
        }
      }
      
      /* Ensure no hover effects on container */
      &:hover {
        background: transparent !important;
      }
      
      /* Make sure chart is transparent */
      chart-card {
        background: transparent !important;
      }
    }
    
    .chart-nav {
      display: flex;
      gap: 8px;
      margin-bottom: 12px;
    }
    
    .chart-nav button {
      background: transparent;
      border: 1px solid var(--border-color);
      color: var(--text-color);
    }
    
    .chart-nav button.active {
      background: rgba(255, 255, 255, 0.1);
    }
    
    .chart-wrapper {
      flex: 1;
      min-height: 0;
    }
    
    .chart-card {
      height: 100%;
      background: transparent !important;
      box-shadow: none !important;
      border: none !important;
      
      ::ng-deep .echarts,
      ::ng-deep .echarts *,
      ::ng-deep .echarts .chart-container,
      ::ng-deep .echarts canvas,
      ::ng-deep .echarts .chart-container canvas {
        background: transparent !important;
        background-color: transparent !important;
      }
      
      /* Disable all hover effects */
      &:hover {
        transform: none !important;
        box-shadow: none !important;
      }
      
      /* Disable hover on chart elements */
      ::ng-deep *:hover {
        background: transparent !important;
        background-color: transparent !important;
      }
    }
    
    .table-container {
      flex: 1;
      min-height: 0;
      display: flex;
      flex-direction: column;
    }
    
    mat-card {
      background: transparent !important;
      height: 100%;
      display: flex;
      flex-direction: column;
    }
    
    .card-glass {
      background: transparent !important;
      backdrop-filter: none !important;
      -webkit-backdrop-filter: none !important;
      color: var(--text-color) !important;
      box-shadow: none !important;
      border: none !important;
    }
    
    mat-form-field {
      --mdc-filled-text-field-container-color: transparent !important;
    }
    
    .dashboard-container {
      height: 100vh;
      max-height: 100vh;
      overflow: hidden;
      padding: 16px;
      display: flex;
      flex-direction: column;
      box-sizing: border-box;
    }

    .grid {
      display: grid;
      grid-template-columns: minmax(250px, 280px) minmax(300px, 1fr) minmax(350px, 420px);
      grid-template-rows: auto 1fr;
      gap: 16px;
      flex: 1;
      min-height: 0;
      height: 100%;
      max-width: 2000px;
      margin: 0 auto;
      width: 100%;
      align-items: stretch;
      overflow: hidden;
      padding: 8px;
      box-sizing: border-box;
    }

    @media (max-width: 1400px) {
      .grid {
        grid-template-columns: minmax(250px, 1fr) minmax(300px, 1.5fr);
        grid-template-areas:
          "left center"
          "right right";
      }
      .left { grid-area: left; }
      .center { grid-area: center; }
      .right { grid-area: right; }
    }

    @media (max-width: 900px) {
      .grid {
        grid-template-columns: 1fr;
        grid-template-areas:
          "left"
          "center"
          "right";
      }
    }
    
    .left, .center, .right {
      height: 100%;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      min-height: 0;
      background: transparent !important;
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 8px;
      box-shadow: none !important;
      transition: all 0.2s ease;
    }

    /* Ensure content doesn't overflow on smaller screens */
    @media (max-width: 900px) {
      .left, .center, .right {
        height: auto;
        min-height: 300px;
      }
    }
    
    .right {
      overflow: hidden;
    }

    .right ::ng-deep .table-container {
      height: 100%;
      display: flex;
      flex-direction: column;
      min-height: 0;
    }
    
    .right ::ng-deep .table-wrapper {
      flex: 1;
      min-height: 0;
      display: flex;
      flex-direction: column;
    }
    
    .right ::ng-deep .mat-mdc-table {
      display: flex;
      flex-direction: column;
      flex: 1;
      min-height: 0;
    }
    
    .right ::ng-deep .mat-mdc-header-row,
    .right ::ng-deep .mat-mdc-row {
      display: table;
      width: 100%;
      table-layout: fixed;
    }

    .kpis {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 8px;
      margin-bottom: 16px;
    }
    
    .kpis ::ng-deep .kpi-card {
      padding: 8px 12px;
    }
    
    .kpis ::ng-deep .value {
      font-size: 1.4rem;
      font-weight: 600;
    }
    
    .kpis ::ng-deep .label {
      font-size: 0.75rem;
      opacity: 0.8;
    }

    .chart-container {
      background: transparent !important;
      border: none;
      padding: 0;
      flex: 1;
      display: flex;
      flex-direction: column;
      min-height: 0;
    }

    .chart-nav {
      display: flex;
      gap: 8px;
      margin-bottom: 20px;
      flex-wrap: wrap;
      flex-shrink: 0;
    }

    .chart-nav button {
      display: flex;
      align-items: center;
      gap: 6px;
      transition: all 0.2s ease;
      white-space: nowrap;
    }

    .chart-nav button.active {
      background: rgba(123, 92, 255, 0.2);
      border-color: rgba(123, 92, 255, 0.5);
    }

    .chart-wrapper {
      flex: 1;
      min-height: 400px;
      display: flex;
      flex-direction: column;
      overflow: hidden;
    }

    .chart-card {
      flex: 1;
      min-height: 0;
      display: flex;
      flex-direction: column;
    }
    
    .chart-card ::ng-deep .card-content {
      flex: 1;
      min-height: 0;
      display: flex;
      flex-direction: column;
    }
    
    .chart-card ::ng-deep .chart {
      flex: 1;
      min-height: 0;
    }

    .no-chart {
      color: var(--muted);
      text-align: center;
      padding: 40px;
    }

    .no-chart p {
      margin: 0;
      font-size: 1.1rem;
      opacity: 0.7;
    }

    .card-glass {
      background: transparent !important;
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 12px;
      padding: 20px;
      height: 100%;
      transition: all 0.3s ease;
      box-shadow: none !important;
      
      &:hover {
        background: transparent !important;
        transform: none;
        box-shadow: none !important;
      }
      
      // Ensure all children have transparent backgrounds
      &, & > * {
        background: transparent !important;
      }
    }

    .card-glass:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
    }

    /* Responsive breakpoints */
    @media (max-width: 1800px) {
      .kpis {
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 12px;
        
        ::ng-deep .kpi-card {
          padding: 8px 12px;
          
          .value {
            font-size: 1.2rem;
          }
          
          .label {
            font-size: 0.7rem;
          }
        }
      }
    }
    
    @media (max-width: 1600px) {
      .grid {
        grid-template-columns: 240px 1fr 380px;
      }
      
      .kpis {
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 8px;
        
        ::ng-deep .kpi-card {
          padding: 6px 8px;
          
          .value {
            font-size: 1.1rem;
          }
          
          .label {
            font-size: 0.65rem;
          }
        }
      }
      
      .row2 {
        grid-template-columns: 1fr;
      }
    }

    @media (max-width: 1400px) {
      .kpis {
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 6px;
        
        ::ng-deep .kpi-card {
          padding: 4px 6px;
          
          .value {
            font-size: 1rem;
          }
          
          .label {
            font-size: 0.6rem;
          }
        }
      }
    }
    
    @media (max-width: 1200px) {
      .grid {
        grid-template-columns: 1fr 1fr;
        grid-template-areas: 
          "filters filters"
          "left right"
          "center center";
      }
      
      .left { grid-area: filters; }
      .center { grid-area: center; }
      .right { grid-area: right; }
      
      .kpis {
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 4px;
        
        ::ng-deep .kpi-card {
          padding: 4px;
          
          .value {
            font-size: 0.9rem;
          }
          
          .label {
            font-size: 0.6rem;
          }
        }
      }
      
      .row2 {
        grid-template-columns: repeat(2, 1fr);
      }
    }

    @media (max-width: 900px) {
      .grid {
        grid-template-columns: 1fr;
        grid-template-areas: 
          "filters"
          "right"
          "center";
      }
      
      .kpis {
        grid-template-columns: repeat(2, 1fr);
      }
      
      .row2 {
        grid-template-columns: 1fr;
      }
    }

    @media (max-width: 600px) {
      .kpis {
        grid-template-columns: 1fr;
      }
      
      .grid {
        padding: 12px;
        gap: 16px;
      }
    }
  `]
})
export class DashboardPage {
  store = inject(DataStoreService);

  tableRows: TableRow[] = [];
  scatterOpts: any = {};
  pieOpts: any = {};
  stackedOpts: any = {};
  histogramOpts: {
    backgroundColor?: string;
    tooltip?: any;
    xAxis?: any;
    yAxis?: any;
    visualMap?: any;
    series?: any[];
    legend?: any;
    grid?: any;
  } = {};
  
  activeChart: ChartType = 'scatter';
  
  chartTypes: {id: ChartType, label: string, icon: string}[] = [
    { id: 'scatter', label: 'Scatter Plot', icon: 'scatter_plot' },
    { id: 'line', label: 'Line Graph', icon: 'show_chart' },
    { id: 'histogram', label: 'Histogram', icon: 'bar_chart' }
  ];

  constructor() {
    // ✅ constructor/field init is an injection context
    effect(() => this.buildCharts());
    effect(() => this.buildTable());
  }

  private prepareLineChartData(points: {x: number, y: number}[]) {
    // Group points by radius (y) and calculate average period (x) for each radius
    const radiusGroups = new Map<number, {sum: number, count: number}>();
    
    points.forEach(point => {
      const radius = Math.round(point.y * 10) / 10; // Group by radius with 0.1 precision
      if (!radiusGroups.has(radius)) {
        radiusGroups.set(radius, { sum: 0, count: 0 });
      }
      const group = radiusGroups.get(radius)!;
      group.sum += point.x;
      group.count++;
    });
    
    // Convert to array of [radius, avgPeriod] pairs and sort by radius
    return Array.from(radiusGroups.entries())
      .map(([radius, {sum, count}]) => [radius, sum / count])
      .sort((a, b) => a[0] - b[0]);
  }

  // Shared tooltip style for all charts
  private tooltipStyle = {
    backgroundColor: 'rgba(10, 12, 16, 0.98)',
    borderColor: 'rgba(255, 255, 255, 0.15)',
    borderWidth: 1,
    padding: [12, 16],
    textStyle: {
      color: '#f0f0f0',
      fontSize: '13px',
      lineHeight: 1.5,
      fontFamily: 'Roboto, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
      fontWeight: 400
    },
    extraCssText: 'box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3); border-radius: 6px; backdrop-filter: blur(4px);'
  };

  private buildCharts() {
    const pts = this.store.scatterRadiusPeriod();
    const points = pts.map(p => ({
      x: p.value[1], // radius (x)
      y: p.value[0], // period (y)
      name: p.name || ''
    }));
    
    // Group points by disposition
    const dispositions = new Set<string>();
    const seriesByDisposition = new Map<string, any[]>();
    
    pts.forEach(point => {
      const planet = this.store.filtered().find(p => (p.name || p.id) === point.name);
      const disposition = planet?.disposition || 'Unknown';
      
      if (!seriesByDisposition.has(disposition)) {
        seriesByDisposition.set(disposition, []);
        dispositions.add(disposition);
      }
      
      seriesByDisposition.get(disposition)?.push({
        ...point,
        itemStyle: {
          color: this.getDispositionColor(disposition),
          borderColor: 'rgba(255, 255, 255, 0.6)',
          borderWidth: 0.5,
          opacity: 0.9
        }
      });
    });
    
    // Create scatter series for each disposition
    const scatterSeriesData = Array.from(dispositions).map(disposition => ({
      name: disposition,
      type: 'scatter',
      symbolSize: 8,
      data: seriesByDisposition.get(disposition) || [],
      itemStyle: {
        color: this.getDispositionColor(disposition),
        borderColor: 'rgba(255, 255, 255, 0.6)',
        borderWidth: 0.5,
        opacity: 0.9
      },
      tooltip: {
        trigger: 'item',
        formatter: (params: any) => {
          const planet = this.store.filtered().find(p => (p.name || p.id) === params.data.name);
          const disposition = planet?.disposition || 'Unknown';
          const dispositionColor = this.getDispositionColor(disposition);
          
          return `
            <div style="margin: 0 0 12px 0; padding: 0 0 10px 0; font-weight: 500; color: #fff; font-size: 14px; border-bottom: 1px solid rgba(255, 255, 255, 0.1);">
              ${params.data.name || 'Unnamed Planet'}
            </div>
            <div style="display: flex; align-items: center; margin: 10px 0; padding: 0;">
              <span style="display: inline-block; width: 10px; height: 10px; background: ${dispositionColor}; border-radius: 50%; margin-right: 10px;"></span>
              <span style="color: #aaa; font-size: 12px; min-width: 80px;">Disposition</span>
              <span style="color: ${dispositionColor}; font-weight: 500; margin-left: 4px;">${disposition}</span>
            </div>
            <div style="margin: 10px 0; padding: 0; display: flex; align-items: center;">
              <span style="color: #aaa; font-size: 12px; min-width: 80px;">Radius</span>
              <span style="color: #f0f0f0;">${params.data.value[0].toFixed(2)} <span style="color: #888;">Earth Radii</span></span>
            </div>
            <div style="margin: 10px 0 0 0; padding: 0; display: flex; align-items: center;">
              <span style="color: #aaa; font-size: 12px; min-width: 80px;">Period</span>
              <span style="color: #f0f0f0;">${params.data.value[1].toFixed(2)} <span style="color: #888;">days</span></span>
            </div>`;
        }
      }
    }));
    
    // Scatter plot options with reversed axes
    this.scatterOpts = {
      legend: {
        show: true,
        top: 0,
        right: 10,
        textStyle: {
          color: 'rgba(255, 255, 255, 0.8)',
          fontSize: 12,
          fontFamily: 'Roboto, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
        },
        pageTextStyle: {
          color: '#aaa'
        },
        pageIconColor: '#4fc3f7',
        pageIconInactiveColor: '#555',
        pageButtonGap: 6,
        pageButtonItemGap: 2,
        pageIconSize: 10,
        itemGap: 16,
        itemWidth: 12,
        itemHeight: 12,
        borderRadius: 2
      },
      xAxis: {
        type: 'log',
        name: 'Planet Radius (Earth Radii)',
        nameTextStyle: { color: 'rgba(255, 255, 255, 0.7)' },
        nameLocation: 'middle',
        nameGap: 30,
        axisLine: { lineStyle: { color: 'rgba(255, 255, 255, 0.3)' } },
        axisLabel: { color: 'rgba(255, 255, 255, 0.7)' },
        splitLine: { lineStyle: { color: 'rgba(255, 255, 255, 0.1)' } }
      },
      yAxis: {
        type: 'log',
        name: 'Orbital Period (days)',
        nameTextStyle: { color: 'rgba(255, 255, 255, 0.7)' },
        nameLocation: 'middle',
        nameGap: 35,
        axisLine: { lineStyle: { color: 'rgba(255, 255, 255, 0.3)' } },
        axisLabel: { color: 'rgba(255, 255, 255, 0.7)' },
        splitLine: { lineStyle: { color: 'rgba(255, 255, 255, 0.1)' } }
      },
      series: scatterSeriesData
    };

    // Prepare data for line chart with multiple lines by disposition
    const radiusBins: {[key: number]: {[disposition: string]: {sum: number, count: number}}} = {};
    
    // Group points by radius bin and disposition
    pts.forEach(point => {
      const planet = this.store.filtered().find(p => (p.name || p.id) === point.name);
      const disposition = planet?.disposition || 'Unknown';
      const radius = point.value[1];
      const period = point.value[0];
      
      // Round radius to nearest 0.1 for binning
      const radiusBin = Math.round(radius * 10) / 10;
      
      if (!radiusBins[radiusBin]) {
        radiusBins[radiusBin] = {};
      }
      
      if (!radiusBins[radiusBin][disposition]) {
        radiusBins[radiusBin][disposition] = { sum: 0, count: 0 };
      }
      
      radiusBins[radiusBin][disposition].sum += period;
      radiusBins[radiusBin][disposition].count++;
    });
    
    // Create series for each disposition
    const lineSeries: any[] = [];
    const allDispositions = new Set<string>();
    
    // First, collect all unique dispositions
    Object.values(radiusBins).forEach(bin => {
      Object.keys(bin).forEach(disp => allDispositions.add(disp));
    });
    
    // Create a series for each disposition
    allDispositions.forEach(disposition => {
      const data: [number, number][] = [];
      
      // Sort radius bins
      const sortedRadii = Object.keys(radiusBins)
        .map(Number)
        .sort((a, b) => a - b);
      
      // Calculate average period for each radius bin
      sortedRadii.forEach(radius => {
        const bin = radiusBins[radius];
        if (bin[disposition]) {
          const avgPeriod = bin[disposition].sum / bin[disposition].count;
          data.push([radius, avgPeriod]);
        }
      });
      
      if (data.length > 0) {
        const color = this.getDispositionColor(disposition);
        lineSeries.push({
          name: disposition,
          type: 'line',
          smooth: true,
          symbol: 'circle',
          symbolSize: 6,
          data: data,
          lineStyle: {
            color: color,
            width: 2
          },
          itemStyle: {
            color: color
          },
          emphasis: {
            itemStyle: {
              color: 'rgba(255, 255, 255, 0.9)',
              borderColor: color,
              borderWidth: 2
            }
          }
        });
      }
    });
    
    this.pieOpts = {
      backgroundColor: 'transparent',
      legend: {
        show: true,
        top: 0,
        right: 10,
        textStyle: {
          color: 'rgba(255, 255, 255, 0.8)',
          fontSize: 12,
          fontFamily: 'Roboto, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
        },
        pageTextStyle: {
          color: '#aaa'
        },
        pageIconColor: '#4fc3f7',
        pageIconInactiveColor: '#555',
        pageButtonGap: 6,
        pageButtonItemGap: 2,
        pageIconSize: 10,
        itemGap: 16,
        itemWidth: 12,
        itemHeight: 12,
        borderRadius: 2
      },
      tooltip: {
        ...this.tooltipStyle,
        trigger: 'axis',
        formatter: (params: any[]) => {
          const radius = params[0].value[0];
          let content = `
            <div style="margin: 0 0 12px 0; padding-bottom: 8px; font-weight: 500; color: #fff; font-size: 14px; border-bottom: 1px solid rgba(255, 255, 255, 0.1);">
              Radius: ${radius.toFixed(2)} Earth Radii
            </div>`;
          
          // Sort by disposition name for consistent ordering
          const sortedParams = [...params].sort((a, b) => a.seriesName.localeCompare(b.seriesName));
          
          sortedParams.forEach(item => {
            if (item.value && item.value[1] !== undefined) {
              const disposition = item.seriesName;
              const period = item.value[1].toFixed(2);
              const color = this.getDispositionColor(disposition);
              
              content += `
                <div style="margin: 8px 0; display: flex; align-items: center;">
                  <span style="display: inline-block; width: 10px; height: 10px; background: ${color}; border-radius: 50%; margin-right: 8px;"></span>
                  <span style="flex: 1; color: #f0f0f0;">${disposition}</span>
                  <span style="margin-left: 12px; font-weight: 500; color: #4fc3f7;">${period} days</span>
                </div>`;
            }
          });
          
          return content;
        }
      },
      xAxis: {
        type: 'log',
        name: 'Planet Radius (Earth Radii)',
        nameTextStyle: { color: 'rgba(255, 255, 255, 0.7)' },
        nameLocation: 'middle',
        nameGap: 30,
        axisLine: { lineStyle: { color: 'rgba(255, 255, 255, 0.3)' } },
        axisLabel: { color: 'rgba(255, 255, 255, 0.7)' },
        splitLine: { lineStyle: { color: 'rgba(255, 255, 255, 0.1)' } }
      },
      yAxis: {
        type: 'log',
        name: 'Average Orbital Period (days)',
        nameTextStyle: { color: 'rgba(255, 255, 255, 0.7)' },
        nameLocation: 'middle',
        nameGap: 35,
        axisLine: { lineStyle: { color: 'rgba(255, 255, 255, 0.3)' } },
        axisLabel: { color: 'rgba(255, 255, 255, 0.7)' },
        splitLine: { lineStyle: { color: 'rgba(255, 255, 255, 0.1)' } }
      },
      series: lineSeries
    };

    const bar = this.store.barByYearMethod();
    this.stackedOpts = {
      backgroundColor: 'transparent',
      tooltip: {
        ...this.tooltipStyle,
        trigger: 'axis',
        axisPointer: {
          type: 'shadow',
          shadowStyle: {
            color: 'rgba(255, 255, 255, 0.05)'
          }
        },
        formatter: (params: any[]) => {
          const year = params[0].axisValue;
          let content = `
            <div style="margin: 0 0 12px 0; padding-bottom: 8px; font-weight: 500; color: #fff; font-size: 14px; border-bottom: 1px solid rgba(255, 255, 255, 0.1);">
              ${year} - Discovery Methods
            </div>`;
          
          // Sort by value descending
          const sortedParams = [...params].sort((a, b) => b.value - a.value);
          
          sortedParams.forEach(item => {
            content += `
              <div style="margin: 8px 0; display: flex; align-items: center;">
                <span style="display: inline-block; width: 10px; height: 10px; background: ${item.color}; border-radius: 2px; margin-right: 8px;"></span>
                <span style="flex: 1; color: #f0f0f0;">${item.seriesName}</span>
                <span style="margin-left: 12px; font-weight: 500; color: #4fc3f7;">${item.value}</span>
              </div>`;
          });
          
          const total = params.reduce((sum, item) => sum + item.value, 0);
          content += `
            <div style="margin: 12px 0 2px 0; padding: 10px 0 0 0; color: #fff; font-weight: 500; border-top: 1px solid rgba(255, 255, 255, 0.1);">
              <span style="color: #aaa;">Total: </span>
              <span style="color: #4fc3f7; font-size: 1.1em;">${total}</span>
            </div>`;
            
          return content;
        }
      },
      legend: {
        top: 0,
        right: 0,
        textStyle: {
          color: 'rgba(255, 255, 255, 0.8)',
          fontSize: 12,
          fontFamily: 'Roboto, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
        },
        pageTextStyle: {
          color: '#aaa'
        },
        pageIconColor: '#4fc3f7',
        pageIconInactiveColor: '#555',
        pageButtonGap: 6,
        pageButtonItemGap: 2,
        pageIconSize: 10,
        itemGap: 16,
        itemWidth: 12,
        itemHeight: 12,
        borderRadius: 2
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true
      },
      xAxis: { 
        type: 'category', 
        data: bar.years,
        axisLine: { lineStyle: { color: 'rgba(255, 255, 255, 0.3)' } },
        axisLabel: { color: 'rgba(255, 255, 255, 0.7)' },
        splitLine: { show: false }
      },
      yAxis: { 
        type: 'value',
        axisLine: { lineStyle: { color: 'rgba(255, 255, 255, 0.3)' } },
        axisLabel: { color: 'rgba(255, 255, 255, 0.7)' },
        splitLine: { lineStyle: { color: 'rgba(255, 255, 255, 0.1)' } }
      },
      series: bar.series.map(s => ({
        ...s,
        itemStyle: {
          opacity: 0.9,
          borderWidth: 0
        }
      }))
    };

    // Generate histogram data
    console.log('Generating histogram data for points:', points);
    const heatmapData = this.createHistogramData(points);
    console.log('Generated heatmap data:', heatmapData);
    
    if (heatmapData.length === 0) {
      console.warn('No valid heatmap data was generated. Check if points have valid radius and period values.');
      console.log('Sample points:', points.slice(0, 5));
    }
    
    // Group points by disposition
    const dispositionMap = new Map<string, {x: number, y: number}[]>();
    
    points.forEach(point => {
      if (point.x <= 0) return; // Skip invalid data
      
      const planet = this.store.filtered().find(p => 
        p.pl_rade === point.x || p.koi_prad === point.x
      );
      
      if (!planet) return;
      
      const disposition = planet.disposition || 'Unknown';
      if (!dispositionMap.has(disposition)) {
        dispositionMap.set(disposition, []);
      }
      dispositionMap.get(disposition)?.push(point);
    });
    
    // Calculate bins for the histogram
    const radiusData = points.filter(p => p.x > 0).map(p => p.x);
    const minRadius = Math.min(...radiusData);
    const maxRadius = Math.max(...radiusData);
    const binCount = 15;
    const binSize = (maxRadius - minRadius) / binCount;
    
    // Prepare x-axis labels
    const xAxisData = [];
    for (let i = 0; i < binCount; i++) {
      const binStart = minRadius + i * binSize;
      const binEnd = minRadius + (i + 1) * binSize;
      xAxisData.push(`${binStart.toFixed(1)}-${binEnd.toFixed(1)}`);
    }
    
    // Create series for each disposition
    const histogramSeries = Array.from(dispositionMap.entries()).map(([disposition, points]) => {
      // Initialize bins for this disposition
      const bins = new Array(binCount).fill(0);
      
      // Count values in each bin
      points.forEach(point => {
        if (point.x <= 0) return;
        const binIndex = Math.min(Math.floor((point.x - minRadius) / binSize), binCount - 1);
        bins[binIndex]++;
      });
      
      return {
        name: disposition,
        type: 'bar',
        stack: 'total',
        emphasis: { focus: 'series' },
        itemStyle: {
          color: this.getDispositionColor(disposition),
          borderRadius: [3, 3, 0, 0],
          opacity: 0.9
        },
        data: bins.map(count => ({
          value: count,
          itemStyle: {
            color: this.getDispositionColor(disposition),
            opacity: count > 0 ? 0.9 : 0
          }
        }))
      };
    });
    
    this.histogramOpts = {
      backgroundColor: 'transparent',
      tooltip: {
        ...this.tooltipStyle,
        trigger: 'axis',
        axisPointer: {
          type: 'shadow',
          shadowStyle: {
            color: 'rgba(255, 255, 255, 0.1)'
          }
        },
        formatter: (params: any[]) => {
          if (!params.length) return '';
          
          // Get the bin range from the first parameter
          const binRange = params[0].axisValue;
          const [start, end] = binRange.split('-').map(Number);
          
          // Calculate total count for this bin
          const total = params.reduce((sum, item) => sum + (item.value || 0), 0);
          
          // Sort by value descending
          const sortedParams = [...params].sort((a, b) => (b.value || 0) - (a.value || 0));
          
          let content = `
            <div style="margin: 0 0 10px 0; padding-bottom: 8px; font-weight: 500; color: #fff; font-size: 14px; border-bottom: 1px solid rgba(255, 255, 255, 0.1);">
              Radius Range: ${start.toFixed(1)} - ${end.toFixed(1)} Earth Radii
            </div>
            <div style="margin: 0 0 8px 0; color: #f0f0f0;">
              <span style="color: #aaa;">Total Planets:</span> 
              <span style="color: #fff; font-weight: 500;">${total}</span>
            </div>`;
          
          // Add each disposition's count with color
          sortedParams.forEach(item => {
            if (item.value > 0) {
              const color = item.color || '#666';
              content += `
                <div style="margin: 6px 0; display: flex; align-items: center;">
                  <span style="display: inline-block; width: 10px; height: 10px; background: ${color}; border-radius: 2px; margin-right: 8px;"></span>
                  <span style="flex: 1; color: #f0f0f0;">${item.seriesName}</span>
                  <span style="color: #4fc3f7; font-weight: 500;">${item.value}</span>
                </div>`;
            }
          });
          
          return content;
        }
      },
      legend: {
        show: true,
        top: 0,
        right: 10,
        data: Array.from(dispositionMap.keys()),
        width: 'auto',
        itemWidth: 14,
        itemHeight: 8,
        itemGap: 12,
        textStyle: {
          color: 'rgba(255, 255, 255, 0.8)',
          fontSize: 12,
          fontFamily: 'Roboto, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
          width: 'auto'
        },
        pageTextStyle: {
          color: '#aaa',
          width: 'auto'
        },
        pageIconColor: '#4fc3f7',
        pageIconInactiveColor: '#555',
        pageButtonGap: 6,
        pageButtonItemGap: 2,
        pageIconSize: 10
      },
      grid: {
        left: '13%',
        right: '14%',
        bottom: '13%',
        containLabel: true
      },
      xAxis: {
        type: 'category',
        data: xAxisData,
        name: 'Planet Radius (Earth Radii)',
        nameTextStyle: { color: 'rgba(255, 255, 255, 0.7)' },
        nameLocation: 'middle',
        nameGap: 30,
        axisLine: { lineStyle: { color: 'rgba(255, 255, 255, 0.3)' } },
        axisLabel: { 
          color: 'rgba(255, 255, 255, 0.7)',
          rotate: 0,
          interval: Math.ceil(binCount / 10), // Show fewer labels to avoid overlap
          formatter: (value: string) => {
            const [start] = value.split('-');
            return `${Number(start).toFixed(1)}`;
          }
        },
        axisTick: {
          alignWithLabel: true
        },
        splitLine: { 
          lineStyle: { 
            color: 'rgba(255, 255, 255, 0.1)' 
          } 
        }
      },
      yAxis: {
        type: 'value',
        name: 'Number of Planets',
        nameTextStyle: { color: 'rgba(255, 255, 255, 0.7)' },
        nameLocation: 'middle',
        nameGap: 35,
        axisLine: { lineStyle: { color: 'rgba(255, 255, 255, 0.3)' } },
        axisLabel: { 
          color: 'rgba(255, 255, 255, 0.7)'
        },
        splitLine: { 
          lineStyle: { 
            color: 'rgba(255, 255, 255, 0.1)' 
          } 
        }
      },
      series: histogramSeries
    };
  }

  private createHistogramData(points: {x: number, y: number}[]): [number, number, number][] {
    console.log('createHistogramData called with points:', points);
    
    // Define the number of bins for radius and period (log scale)
    const radiusBins = 20;
    const periodBins = 20;
    
    // Find min/max values for radius and period (log scale)
    const radii = points.map(p => p.x).filter(x => x > 0);
    const periods = points.map(p => p.y).filter(y => y > 0);
    
    if (radii.length === 0 || periods.length === 0) {
      return [];
    }
    
    const minRadius = Math.log10(Math.min(...radii));
    const maxRadius = Math.log10(Math.max(...radii));
    const minPeriod = Math.log10(Math.min(...periods));
    const maxPeriod = Math.log10(Math.max(...periods));
    
    // Initialize bins
    const bins: number[][] = Array(radiusBins).fill(0).map(() => Array(periodBins).fill(0));
    
    // Calculate bin sizes
    const radiusStep = (maxRadius - minRadius) / radiusBins;
    const periodStep = (maxPeriod - minPeriod) / periodBins;
    
    // Populate bins
    points.forEach(point => {
      if (point.x <= 0 || point.y <= 0) return; // Skip invalid data
      
      const logRadius = Math.log10(point.x);
      const logPeriod = Math.log10(point.y);
      
      // Calculate bin indices
      let radiusIdx = Math.min(
        radiusBins - 1,
        Math.max(0, Math.floor((logRadius - minRadius) / radiusStep))
      );
      
      let periodIdx = Math.min(
        periodBins - 1,
        Math.max(0, Math.floor((logPeriod - minPeriod) / periodStep))
      );
      
      bins[radiusIdx][periodIdx]++;
    });
    
    // Convert bins to heatmap data format: [radius, period, count]
    const heatmapData: [number, number, number][] = [];
    
    for (let i = 0; i < radiusBins; i++) {
      for (let j = 0; j < periodBins; j++) {
        const count = bins[i][j];
        if (count > 0) {
          // Convert back from log scale to original scale for display
          const radius = Math.pow(10, minRadius + (i + 0.5) * radiusStep);
          const period = Math.pow(10, minPeriod + (j + 0.5) * periodStep);
          heatmapData.push([radius, period, count]);
        }
      }
    }
    
    return heatmapData;
  }

  private getDispositionColor(disposition: string): string {
    const colorMap: {[key: string]: string} = {
      'Confirmed': '#4CAF50',  // Green
      'Candidate': '#FFC107',  // Amber
      'False Positive': '#F44336',  // Red
      'Controversial': '#9C27B0',  // Purple
      'Retracted': '#9E9E9E',  // Grey
      'default': '#2196F3'  // Blue for unknown/other
    };
    
    const normalizedDisposition = (disposition || '').toLowerCase();
    const matchedKey = Object.keys(colorMap).find(key => 
      normalizedDisposition.includes(key.toLowerCase())
    );
    
    return matchedKey ? colorMap[matchedKey] : colorMap['default'];
  }

  private buildTable() {
    this.tableRows = this.store.filtered().map((r: any) => ({
      id: r.id,
      name: r.name || r.id,
      source: r.source,
      disposition: r.disposition,
      period: r.pl_orbper ?? r.koi_period ?? null,
      radius: r.pl_rade ?? r.koi_prad ?? null,
      year: r.disc_year ?? null
    }));
  }
}
