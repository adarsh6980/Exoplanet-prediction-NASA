// src/app/pages/upload.page.ts
import { Component } from '@angular/core';
import { NgIf, NgFor } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import * as Papa from 'papaparse';

import {
  collection, writeBatch, doc, serverTimestamp, Firestore,
  getDocs, query, limit as qlimit
} from 'firebase/firestore';
import { db } from '../lib/firebase';

@Component({
  standalone: true,
  selector: 'app-upload',
  imports: [NgIf, NgFor, FormsModule, MatCardModule, MatButtonModule, MatProgressBarModule],
  template: `
  <mat-card class="card-glass">
    <h2>Import CSV → Firestore (throttled + resume + dup-header safe)</h2>
    <p>
      Choose NASA <b>cumulative</b> CSV. Trims values, tolerates duplicate headers,
      generates fallback ids when names are missing, and writes in small batches with backoff.
    </p>

    <div class="row">
      <input type="file" accept=".csv,text/csv" (change)="onPick($event)" />
      <label>Max rows this run:
        <input type="number" min="100" step="100" [(ngModel)]="maxRows" style="width:100px">
      </label>
      <label>Mode:
        <select [(ngModel)]="mode">
          <option value="gentle">gentle</option>
          <option value="fast">fast</option>
        </select>
      </label>
      <button mat-stroked-button color="warn" (click)="nukePlanets()" [disabled]="busy">☢️ Nuke planets</button>
      <button mat-button color="warn" (click)="clearProgress()" [disabled]="busy">Clear resume</button>
    </div>

    <div *ngIf="resumeAvailable" class="row">
      <button mat-raised-button color="accent" (click)="resume()">Resume last import</button>
      <span class="tip">Resumes at row {{ progress.skip }} (same file name required).</span>
    </div>

    <div *ngIf="busy" style="margin-top:12px;">
      <p>{{ statusLine }}</p>
      <mat-progress-bar mode="indeterminate"></mat-progress-bar>
    </div>

    <p *ngIf="errorMsg" style="color:#ff8a80; margin-top:10px;">Error: {{ errorMsg }}</p>
    <p *ngIf="done" style="margin-top:10px;">Done! Imported {{ imported }} rows.</p>

    <div *ngIf="log.length" class="log">
      <div *ngFor="let l of log">{{ l }}</div>
    </div>
  </mat-card>
  `,
  styles: [`
    .row { display:flex; flex-wrap:wrap; gap:12px; align-items:center; }
    .tip { opacity:.75; font-size:12px; }
    .log { margin-top:12px; font-family:ui-monospace, Menlo, Consolas, monospace; font-size:12px; max-height:260px; overflow:auto; opacity:.9; }
  `]
})
export class UploadPage {
  maxRows = 1000;
  mode: 'gentle' | 'fast' = 'gentle';
  busy = false;
  done = false;
  imported = 0;
  errorMsg = '';
  statusLine = '';
  log: string[] = [];

  private LS_KEY = 'exo-import-progress';
  progress: { file?: string; skip: number } = { file: undefined, skip: 0 };
  get resumeAvailable() { return !!(this.progress.file && this.progress.skip > 0); }

  constructor() {
    const saved = localStorage.getItem(this.LS_KEY);
    if (saved) this.progress = JSON.parse(saved);
  }

  onPick(ev: Event) {
    const input = ev.target as HTMLInputElement;
    const file = input?.files?.[0];
    if (!file) return;
    this.startImport(file, 0);
    input.value = '';
  }

  resume() {
    const el = document.createElement('input');
    el.type = 'file';
    el.accept = '.csv,text/csv';
    el.onchange = () => {
      const file = (el.files && el.files[0]) || null;
      if (!file) return;
      if (this.progress.file && file.name !== this.progress.file) {
        alert(`Pick the same file used previously: ${this.progress.file}`);
        return;
      }
      this.startImport(file, this.progress.skip);
    };
    el.click();
  }

  private async startImport(file: File, skipRows: number) {
    this.busy = true; this.done = false; this.errorMsg = ''; this.imported = 0; this.log = [];
    this.statusLine = `Parsing ${file.name}…`;
    this.progress = { file: file.name, skip: skipRows };
    localStorage.setItem(this.LS_KEY, JSON.stringify(this.progress));

    try {
      await this.importCsv(file, db, skipRows);
      this.done = true;
      this.statusLine = `Imported ${this.imported} rows`;
      this.progress = { file: file.name, skip: 0 };
      localStorage.setItem(this.LS_KEY, JSON.stringify(this.progress));
    } catch (e: any) {
      this.errorMsg = e?.message || String(e);
    } finally {
      this.busy = false;
    }
  }

  private async importCsv(file: File, firestore: Firestore, skipRows: number) {
    const coll = collection(firestore, 'planets');

    const BATCH_SIZE = this.mode === 'fast' ? 200 : 100;
    const DELAY_MS   = this.mode === 'fast' ? 120 : 280;
    const LONG_BACKOFF = 25_000;

    let batch = writeBatch(firestore);
    let inBatch = 0;
    let committing = false; // ✅ guard to prevent concurrent commits

    const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

    const commitNow = async () => {
      if (!inBatch || committing) return;
      committing = true;
      let attempt = 0;
      while (true) {
        try {
          await batch.commit();
          // start a fresh batch
          batch = writeBatch(firestore);
          inBatch = 0;
          committing = false;
          await delay(DELAY_MS);
          break;
        } catch (err: any) {
          const msg = String(err?.code || err?.message || err);
          if (msg.includes('resource-exhausted')) {
            this.statusLine = 'Firestore quota exceeded; cooling down and retrying…';
            await delay(LONG_BACKOFF);
          } else {
            attempt++;
            const backoff = Math.min(3000, 250 * 2 ** attempt);
            this.statusLine = `⚠️ transient write error → retrying in ${Math.round(backoff/1000)}s`;
            await delay(backoff);
          }
        }
      }
    };

    // --- Duplicate header handling (quiet) ---
    const headerCounts: Record<string, number> = {};
    const dupSet = new Set<string>();
    const normalizeHeader = (raw: string) => {
      let key = (raw || '').replace(/^\uFEFF/, '').trim();
      if (!key) key = 'unnamed';
      const count = (headerCounts[key] || 0) + 1;
      headerCounts[key] = count;
      if (count > 1) {
        dupSet.add(key);
        return `${key}__dup${count}`;
      }
      return key;
    };

    // helper: safely pick value by key, falling back to any duplicate header variant
    const pick = (row: Record<string, any>, key: string) => {
      if (key in row) return row[key];
      const k = Object.keys(row).find(k => k === key || k.startsWith(key + '__dup'));
      return k ? row[k] : undefined;
    };

    let seen = 0;
    let writtenThisRun = 0;
    let aborted = false;

    await new Promise<void>((resolve, reject) => {
      Papa.parse(file, {
        header: true,
        worker: false,
        comments: '#',
        skipEmptyLines: 'greedy',
        dynamicTyping: false,
        transformHeader: normalizeHeader,
        transform: (v: any) => (typeof v === 'string' ? v.trim() : v),
        step: async (result, parser) => {
          // ✅ ensure NO overlap between step iterations
          parser.pause();
          try {
            if (aborted) { parser.abort(); return; }

            if (seen++ < skipRows) { parser.resume(); return; }

            const r = result.data as Record<string, any>;

            // Prefer confirmed name, then KOI, then KepID; fallback if missing
            const nameRaw =
              s(pick(r,'kepler_name')) ?? s(pick(r,'pl_name')) ??
              s(pick(r,'kepoi_name'))  ?? s(pick(r,'kepid'))  ?? null;

            const displayName = nameRaw || s(pick(r,'kepoi_name')) || s(pick(r,'kepid')) || `row_${seen}`;
            const id = (displayName || `row_${seen}`)
              .toString()
              .replace(/\s+/g, '_')
              .replace(/[^\w.-]/g, '_');

            const data = mapRowCumulative(r, pick);

            // 🔒 write against the current batch (safe: parser paused)
            batch.set(doc(coll, id), {
              ...data,
              name: displayName,
              source: (s(pick(r,'kepler_name')) || s(pick(r,'pl_name'))) ? 'ps' : 'koi',
              nameSearch: tokenise(displayName),
              updatedAt: serverTimestamp(),
            }, { merge: true });

            inBatch++;
            this.imported++;
            this.progress.skip = seen;
            localStorage.setItem(this.LS_KEY, JSON.stringify(this.progress));

            if (inBatch >= BATCH_SIZE) {
              await commitNow(); // batch is reset inside commitNow
            }

            writtenThisRun++;
            if (this.maxRows && writtenThisRun >= this.maxRows) {
              aborted = true;
              await commitNow();
              parser.abort();
              resolve();
            }

            if (this.imported % 200 === 0) {
              this.statusLine = `Imported ${this.imported} rows…`;
            }
          } catch (e) {
            parser.abort();
            reject(e);
          } finally {
            // ✅ resume after we’re done with async work
            parser.resume();
          }
        },
        complete: async () => {
          try {
            await commitNow();
            if (dupSet.size) {
              const list = Array.from(dupSet).slice(0, 8).join(', ');
              const more = dupSet.size > 8 ? ` (+${dupSet.size - 8} more)` : '';
              this.log.push(`⚠️ ${dupSet.size} duplicate header(s) detected: ${list}${more}. Later copies were renamed with "__dupN" suffix.`);
            }
            resolve();
          } catch (e) {
            reject(e);
          }
        },
        error: (err) => reject(err),
      });
    });
  }

  async nukePlanets() {
    if (!confirm('Delete ALL documents in "planets"?')) return;
    this.busy = true; this.errorMsg = ''; this.statusLine = 'Deleting…';

    const delay = (ms: number) => new Promise(res => setTimeout(res, ms));
    let deleted = 0;
    try {
      const coll = collection(db, 'planets');
      while (true) {
        const snap = await getDocs(query(coll, qlimit(200)));
        if (snap.empty) break;
        const batch = writeBatch(db);
        for (const d of snap.docs) batch.delete(d.ref);
        await batch.commit();
        deleted += snap.size;
        this.statusLine = `Deleted ${deleted}…`;
        await delay(180);
      }
      this.log.push(`☑ Nuked planets: ${deleted} docs removed`);
    } catch (e: any) {
      this.errorMsg = e?.message || String(e);
    } finally {
      this.busy = false;
    }
  }

  clearProgress() {
    localStorage.removeItem(this.LS_KEY);
    this.progress = { file: undefined, skip: 0 };
  }
}

/* ---------------- helpers & mapper ---------------- */

function s(v: any) { const t = (v ?? '').toString().trim(); return t.length ? t : null; }
function n(v: any) { const x = Number(v); return Number.isFinite(x) ? x : undefined; }

function tokenise(name: string) {
  return name.toLowerCase().split(/[^\w]+/).filter(Boolean);
}

/** Map a single row from the “cumulative” table. */
function mapRowCumulative(
  r: Record<string, any>,
  pick: (row: Record<string, any>, key: string) => any
) {
  return {
    disposition: s(pick(r,'koi_disposition')) ?? s(pick(r,'koi_pdisposition')) ?? undefined,
    method: s(pick(r,'discoverymethod')) ?? s(pick(r,'discovery_method')) ?? undefined,
    disc_year: n(pick(r,'disc_year') ?? pick(r,'koi_disposition_year')),

    // KOI
    koi_period:   n(pick(r,'koi_period')),
    koi_duration: n(pick(r,'koi_duration')),
    koi_depth:    n(pick(r,'koi_depth')),
    koi_prad:     n(pick(r,'koi_prad')),
    koi_teq:      n(pick(r,'koi_teq')),
    koi_insol:    n(pick(r,'koi_insol')),
    koi_srad:     n(pick(r,'koi_srad')),

    // Planetary Systems (confirmed planets)
    pl_orbper:  n(pick(r,'pl_orbper')),
    pl_rade:    n(pick(r,'pl_rade')),
    pl_bmasse:  n(pick(r,'pl_bmasse')),

    // Stellar context
    st_teff: n(pick(r,'st_teff') ?? pick(r,'koi_steff')),
    st_rad:  n(pick(r,'st_rad')  ?? pick(r,'koi_srad')),
    st_mass: n(pick(r,'st_mass') ?? pick(r,'koi_smass')),
  };
}
