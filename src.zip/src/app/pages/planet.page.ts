// src/app/pages/planet.page.ts
import { Component, OnInit, inject } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { NgIf } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';

import { PlanetService } from '../services/planet.service';
import type { Planet } from '../models/planet';

@Component({
  standalone: true,
  selector: 'app-planet',
  imports: [NgIf, RouterLink, MatCardModule, MatButtonModule],
  template: `
  <mat-card class="card-glass" *ngIf="p as planet; else loadingTpl">
    <h2 style="margin-top:0">{{ planet.name || planet.id }}</h2>
    <div style="opacity:.8; margin-bottom:12px">
      <span>Source: <b>{{ planet.source || '—' }}</b></span>
      &nbsp;•&nbsp; Disposition: <b>{{ planet.disposition || '—' }}</b>
      &nbsp;•&nbsp; Method: <b>{{ planet.method || '—' }}</b>
      &nbsp;•&nbsp; Year: <b>{{ planet.disc_year || '—' }}</b>
    </div>

    <div class="grid">
      <div>
        <h4>Orbit / Size</h4>
        <div>P (days): <b>{{ fmtNum(period(planet)) }}</b></div>
        <div>Rₚ (R⊕): <b>{{ fmtNum(radius(planet)) }}</b></div>
        <div>Mₚ (M⊕): <b>{{ fmtNum(planet.pl_bmasse) }}</b></div>
      </div>
      <div>
        <h4>Host Star</h4>
        <div>Tₑff (K): <b>{{ fmtNum(planet.st_teff) }}</b></div>
        <div>R★ (R☉): <b>{{ fmtNum(planet.st_rad) }}</b></div>
        <div>M★ (M☉): <b>{{ fmtNum(planet.st_mass) }}</b></div>
      </div>
    </div>

    <div style="margin-top:16px">
      <button mat-stroked-button routerLink="/explore">← Back to Explore</button>
    </div>
  </mat-card>

  <ng-template #loadingTpl>
    <mat-card class="card-glass">
      <h3>Loading…</h3>
      <p *ngIf="error" style="color:#ff8a80">Error: {{ error }}</p>
      <button mat-stroked-button routerLink="/explore">Back</button>
    </mat-card>
  </ng-template>
  `,
  styles: [`
    .grid { display:grid; grid-template-columns: 1fr 1fr; gap:16px; }
    @media (max-width: 800px){ .grid { grid-template-columns: 1fr; } }
  `]
})
export class PlanetPage implements OnInit {
  private route = inject(ActivatedRoute);
  private svc = inject(PlanetService);

  p: Planet | null = null;
  error = '';

  async ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    if (!id) { this.error = 'Missing ID'; return; }
    try {
      this.p = await this.svc.getOne(id);
      if (!this.p) this.error = 'Planet not found';
    } catch (e: any) {
      this.error = e?.message || String(e);
    }
  }

  // ------- view helpers (avoid TS casts in template) -------
  period(planet: Planet): number | null {
    const a = planet.pl_orbper;
    const b = (planet as any)['koi_period'];
    return typeof a === 'number' ? a : (Number.isFinite(b) ? b : null);
  }

  radius(planet: Planet): number | null {
    const a = planet.pl_rade;
    const b = (planet as any)['koi_prad'];
    return typeof a === 'number' ? a : (Number.isFinite(b) ? b : null);
  }

  fmtNum(x: number | null | undefined) {
    if (typeof x !== 'number' || !Number.isFinite(x)) return '—';
    return x >= 100 ? Math.round(x) : +x.toFixed(3);
  }
}
