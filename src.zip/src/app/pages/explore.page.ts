// src/app/pages/explore.page.ts
import { Component, OnInit, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NgIf, NgFor, DecimalPipe } from '@angular/common';
import { RouterLink } from '@angular/router';

import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

import { NgxEchartsModule } from 'ngx-echarts';
import { PlanetService } from '../services/planet.service';
import type { Planet } from '../models/planet';

@Component({
  standalone: true,
  selector: 'app-explore',
  imports: [
    // Angular
    NgIf, NgFor, FormsModule, RouterLink, DecimalPipe,
    // Material
    MatCardModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatButtonModule, MatIconModule,
    // Charts
    NgxEchartsModule
  ],
  template: `
  <div class="explore-container">
    <!-- Controls -->
    <div class="controls-container">
      <mat-card class="card-glass">
        <div class="controls">
          <mat-form-field appearance="fill">
            <mat-label>Search name</mat-label>
            <input matInput [(ngModel)]="search" (keyup.enter)="reload()" placeholder="e.g. Kepler-22 b or K00005">
          </mat-form-field>

          <mat-form-field appearance="fill">
            <mat-label>Disposition</mat-label>
            <mat-select [(ngModel)]="disposition" (selectionChange)="reload()">
              <mat-option [value]="null">Any</mat-option>
              <mat-option value="CONFIRMED">Confirmed</mat-option>
              <mat-option value="CANDIDATE">Candidate</mat-option>
              <mat-option value="FALSE POSITIVE">False positive</mat-option>
            </mat-select>
          </mat-form-field>

          <mat-form-field appearance="fill">
            <mat-label>Method</mat-label>
            <mat-select [(ngModel)]="method" (selectionChange)="reload()">
              <mat-option [value]="null">Any</mat-option>
              <mat-option *ngFor="let m of commonMethods" [value]="m">{{ m }}</mat-option>
            </mat-select>
          </mat-form-field>

          <div class="action-buttons">
            <button mat-stroked-button color="primary" (click)="reload()">
              <mat-icon>check_circle</mat-icon>
              <span>Apply</span>
            </button>
            <button mat-stroked-button (click)="clear()">
              <mat-icon>clear</mat-icon>
              <span>Clear</span>
            </button>
          </div>

          <div class="tips">
            <span class="tip" *ngIf="search">Note: pagination is limited for search (index-free mode).</span>
            <span class="tip" *ngIf="!search">Showing {{ rows.length | number }} rows (paged from Firestore).</span>
          </div>
        </div>
      </mat-card>
    </div>

    <!-- Main Content -->
    <div class="main-content">
      <!-- Table -->
      <mat-card class="card-glass table-card">
        <div class="header-row">
          <h3>Planets</h3>
          <div class="pager">
            <button mat-stroked-button (click)="prev()" [disabled]="!canPrev" class="pagination-button">
              <mat-icon>chevron_left</mat-icon>
              <span>Prev</span>
            </button>
            <button mat-stroked-button (click)="next()" [disabled]="!canNext" class="pagination-button">
              <span>Next</span>
              <mat-icon>chevron_right</mat-icon>
            </button>
          </div>
        </div>

        <div class="table-container">
          <table class="data-table">
            <thead>
              <tr class="header">
                <th>Name</th>
                <th>Source</th>
                <th>Disp.</th>
                <th>Period (d)</th>
                <th>Radius (R⊕)</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let p of rows" class="data-row" [routerLink]="['/planet', p.id]">
                <td>{{ p.name || p.id }}</td>
                <td class="muted">{{ p.source || '—' }}</td>
                <td>{{ p.disposition || '—' }}</td>
                <td class="number">{{ fmtNum(getPeriod(p)) }}</td>
                <td class="number">{{ fmtNum(getRadius(p)) }}</td>
                <td class="actions">
                  <button mat-icon-button color="warn" (click)="$event.stopPropagation(); delete(p.id)" aria-label="Delete">
                    <mat-icon>delete</mat-icon>
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </mat-card>

      <!-- Chart -->
      <mat-card class="card-glass chart-card">
        <h3>Radius vs Period</h3>
        <div echarts [options]="chartOptions" class="chart"></div>
        <div class="legend">
          <span class="dot regular"></span> regular
          <span class="dot outlier"></span> outlier (top 5% radius)
        </div>
      </mat-card>
    </div>

    <!-- Quick Add (manual) -->
    <div class="quick-add-container">
      <mat-card class="card-glass quick-add-card">
        <h3>Quick Add Planet</h3>
        <div class="form-grid">
          <mat-form-field appearance="outline">
            <mat-label>Name</mat-label>
            <input matInput [(ngModel)]="form.name" placeholder="Kepler-XYZ b">
          </mat-form-field>

          <mat-form-field appearance="outline">
            <mat-label>Disposition</mat-label>
            <mat-select [(ngModel)]="form.disposition">
              <mat-option [value]="undefined">—</mat-option>
              <mat-option value="CONFIRMED">CONFIRMED</mat-option>
              <mat-option value="CANDIDATE">CANDIDATE</mat-option>
              <mat-option value="FALSE POSITIVE">FALSE POSITIVE</mat-option>
            </mat-select>
          </mat-form-field>

          <mat-form-field appearance="outline">
            <mat-label>Method</mat-label>
            <mat-select [(ngModel)]="form.method">
              <mat-option [value]="undefined">—</mat-option>
              <mat-option *ngFor="let m of commonMethods" [value]="m">{{ m }}</mat-option>
            </mat-select>
          </mat-form-field>

          <mat-form-field appearance="outline">
            <mat-label>Period (days)</mat-label>
            <input matInput type="number" step="0.0001" [(ngModel)]="form.pl_orbper">
          </mat-form-field>

          <mat-form-field appearance="outline">
            <mat-label>Radius (R⊕)</mat-label>
            <input matInput type="number" step="0.0001" [(ngModel)]="form.pl_rade">
          </mat-form-field>

          <div class="form-actions">
            <button mat-stroked-button (click)="form = {}" class="action-button">
              <mat-icon>refresh</mat-icon>
              <span>Reset</span>
            </button>
            <button mat-stroked-button color="primary" (click)="add()" [disabled]="!form.name" class="action-button">
              <mat-icon>add_circle</mat-icon>
              <span>Add Planet</span>
            </button>
          </div>
        </div>
        <div class="tip">Manual add writes a single doc to Firestore with proper <code>nameSearch</code> tokens.</div>
      </mat-card>
    </div>
  </div>
  `,
  styles: [`
    :host {
      display: block;
      padding: 16px;
      max-width: 2000px;
      margin: 0 auto;
      min-height: 100vh;
    }
    
    .explore-container {
      display: flex;
      flex-direction: column;
      gap: 16px;
    }
    
    .controls-container {
      width: 100%;
    }
    
    .controls {
      display: flex;
      flex-wrap: wrap;
      gap: 12px;
      align-items: center;
    }
    
    .action-buttons {
      display: flex;
      gap: 8px;
      margin: 8px 0 16px;
      
      button {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        padding: 0 16px;
        height: 36px;
        border-radius: 18px;
        font-size: 14px;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        transition: all 0.2s ease;
        background: rgba(30, 41, 59, 0.8) !important;
        color: rgba(255, 255, 255, 0.9) !important;
        border: 1px solid rgba(255, 255, 255, 0.2) !important;
        
        mat-icon {
          font-size: 18px;
          width: 18px;
          height: 18px;
          margin-right: 4px;
        }
        
        &:hover {
          background: rgba(51, 65, 85, 0.9) !important;
          transform: translateY(-1px);
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
        }
        
        &:active {
          transform: translateY(0);
          box-shadow: none;
        }
        
        &[color="primary"] {
          background: rgba(59, 130, 246, 0.9) !important;
          border-color: rgba(96, 165, 250, 0.8) !important;
          color: white !important;
          font-weight: 600;
        }
      }
    }
    
    .tips {
      width: 100%;
      margin-top: 8px;
    }
    
    .tip {
      font-size: 12px;
      opacity: 0.7;
      margin-right: 12px;
    }
    
    .main-content {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
      width: 100%;
    }
    
    .table-card {
      grid-column: 1;
      height: 600px;
      display: flex;
      flex-direction: column;
      padding: 24px !important;
    }
    
    .table-container {
      flex: 1;
      overflow: auto;
      padding: 4px; /* Add some space around the table */
    }
    
    .chart-card {
      grid-column: 2;
      height: 600px;
      display: flex;
      flex-direction: column;
      padding: 24px !important;
    }
    
    .chart {
      flex: 1;
      min-height: 0; /* Allows chart to shrink properly */
    }
    
    .quick-add-container {
      grid-column: 1 / -1;
      width: 100%;
    }
    
    .quick-add-card {
      width: 100%;
      padding: 24px !important;
    }
    
    .form-grid {
      margin-bottom: 16px;
    }
    
    .form-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
      gap: 16px;
      align-items: start;
    }
    
    .form-actions {
      grid-column: 1 / -1;
      display: flex;
      justify-content: flex-end;
      gap: 12px;
      margin: 16px 0 8px;
      
      .action-button {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        padding: 0 16px;
        height: 36px;
        border-radius: 18px;
        font-size: 14px;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        transition: all 0.2s ease;
        background: rgba(30, 41, 59, 0.8) !important;
        color: rgba(255, 255, 255, 0.9) !important;
        border: 1px solid rgba(255, 255, 255, 0.2) !important;
        
        mat-icon {
          font-size: 18px;
          width: 18px;
          height: 18px;
          margin-right: 4px;
        }
        
        &:hover:not([disabled]) {
          background: rgba(51, 65, 85, 0.9) !important;
          transform: translateY(-1px);
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
        }
        
        &:active:not([disabled]) {
          transform: translateY(0);
          box-shadow: none;
        }
        
        &[disabled] {
          opacity: 0.5;
          cursor: not-allowed;
        }
        
        &[color="primary"] {
          background: rgba(59, 130, 246, 0.9) !important;
          border-color: rgba(96, 165, 250, 0.8) !important;
          color: white !important;
          font-weight: 600;
        }
      }
    }
    
    .card-glass {
      background: rgba(255, 255, 255, 0.05) !important;
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.1);
      padding: 24px;
      box-sizing: border-box;
    }
    
    .card-glass h3 {
      margin: 0 0 20px 0;
      padding-bottom: 12px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    /* Style for dropdown options in Quick Add section */
    .quick-add-card ::ng-deep .mat-mdc-option {
      background-color: rgba(30, 64, 175, 0.1) !important; /* Light blue background */
    }
    
    .quick-add-card ::ng-deep .mat-mdc-option:hover:not(.mdc-list-item--disabled) {
      background-color: rgba(30, 64, 175, 0.2) !important; /* Slightly darker blue on hover */
    }
    
    .quick-add-card ::ng-deep .mat-mdc-option.mdc-list-item--selected:not(.mdc-list-item--disabled) {
      background-color: rgba(30, 64, 175, 0.3) !important; /* Even darker blue for selected */
    }
    
    .grid { display: grid; gap: 16px; grid-template-columns: 2fr 1fr; }
    @media (max-width: 1000px) { .grid { grid-template-columns: 1fr; } }

    .header-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 16px;
      
      .pager {
        display: flex;
        gap: 8px;
        
        .pagination-button {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 4px;
          padding: 0 12px;
          height: 36px;
          border-radius: 18px;
          font-size: 14px;
          font-weight: 500;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          transition: all 0.2s ease;
          background: rgba(30, 41, 59, 0.8) !important;
          color: rgba(255, 255, 255, 0.9) !important;
          border: 1px solid rgba(255, 255, 255, 0.2) !important;
          
          mat-icon {
            font-size: 18px;
            width: 18px;
            height: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
          }
          
          &:hover:not([disabled]) {
            background: rgba(51, 65, 85, 0.9) !important;
            transform: translateY(-1px);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
          }
          
          &:active:not([disabled]) {
            transform: translateY(0);
            box-shadow: none;
          }
          
          &[disabled] {
            opacity: 0.5;
            cursor: not-allowed;
          }
        }
      }
    }
    
    .pager { display:flex; gap: 12px; }

    .table-container {
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 4px;
      overflow: auto;
      max-height: 500px;
    }

    .data-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 13px;
    }

    .data-table th {
      padding: 8px 12px;
      text-align: left;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      vertical-align: middle;
      font-weight: 500;
    }
    
    .data-table td {
      padding: 8px 12px;
      text-align: left;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      vertical-align: middle;
    }

    .data-table th {
      font-weight: 500;
      color: rgba(255, 255, 255, 0.7);
      background: rgba(255, 255, 255, 0.05);
      position: sticky;
      top: 0;
      z-index: 1;
    }

    .data-table tr.data-row {
      cursor: pointer;
      transition: background-color 0.2s;
    }

    .data-table tr.data-row:hover {
      background: rgba(255, 255, 255, 0.05);
    }

    .data-table .muted {
      color: rgba(255, 255, 255, 0.6);
    }

    .data-table .number {
      font-family: 'Roboto Mono', monospace;
      text-align: left;
      white-space: nowrap;
    }
    
    .data-table th:first-child,
    .data-table td:first-child {
      padding-left: 16px;
    }
    
    .data-table th:last-child,
    .data-table td:last-child {
      padding-right: 16px;
    }

    .data-table .actions {
      text-align: right;
      padding-right: 8px;
    }

    .planet-table {
      width: 100%;
      height: 100%;
      
      .mat-mdc-icon-button {
        color: #f44336 !important; /* Red color for delete icon */
        width: 32px;
        height: 32px;
        line-height: 32px;
        padding: 0;
        
        .mat-icon {
          font-size: 20px;
          width: 20px;
          height: 20px;
          line-height: 20px;
        }
        
        &:hover {
          background-color: rgba(244, 67, 54, 0.1); /* Light red background on hover */
        }
      }
    }

    .icon-sm {
      font-size: 18px;
      width: 18px;
      height: 18px;
      line-height: 18px;
    }

    .chart { height: 360px; }
    .legend { margin-top: 8px; opacity:.8; display:flex; gap:12px; align-items:center; font-size:12px; }
    .dot { width:10px; height:10px; border-radius:50%; display:inline-block; }
    .dot.regular { background:#8ab4f8; }
    .dot.outlier { background:#ff6b6b; }
  `]
})
export class ExplorePage implements OnInit {
  private svc = inject(PlanetService);

  rows: Planet[] = [];
  search: string | null = '';
  disposition: string | null = null;
  method: string | null = null;

  last: any = undefined;
  history: any[] = [];
  canPrev = false; canNext = false;

  commonMethods = ['Transit','Radial Velocity','Imaging','Microlensing','Astrometry','Eclipse Timing Variations'];

  // keep form strictly optional to avoid null type errors
  form: Partial<Planet> & { pl_orbper?: number; pl_rade?: number } = {};

  chartOptions: any = this.baseChart([]);

  ngOnInit() { this.reload(); }

  async reload() {
    this.last = undefined; this.history = [];
    await this.loadPage();
  }

  /** Load a page; when search is set, pagination is disabled (index-free mode). */
  async loadPage(next = false) {
    const searching = !!(this.search && this.search.trim());
    const { rows, last } = await this.svc.page({
      pageSize: 25,
      last: searching ? undefined : (next ? this.last : undefined),
      disposition: this.disposition || null,
      method: this.method || null,
      search: (this.search || '').trim().toLowerCase() || null
    });

    if (!searching && next && this.last) this.history.push(this.last);
    this.rows = rows; this.last = last;

    this.canPrev = !searching && this.history.length > 0;
    this.canNext = !searching && !!last;

    this.updateChartForRows(rows);
  }

  async next() { if (this.canNext) await this.loadPage(true); }

  async prev() {
    if (!this.canPrev) return;
    this.history.pop();
    const cursor = this.history.length ? this.history[this.history.length - 1] : undefined;
    const page = await this.svc.page({
      pageSize: 25,
      last: cursor,
      disposition: this.disposition || null,
      method: this.method || null,
      search: (this.search || '').trim().toLowerCase() || null
    });
    this.rows = page.rows; this.last = page.last;
    this.canPrev = this.history.length > 0; this.canNext = !!page.last;
    this.updateChartForRows(this.rows);
  }

  // ---------- Manual CRUD ----------
  async add() {
    const name = (this.form.name ?? '').toString().trim();
    if (!name) return;

    const payload: Partial<Planet> & Record<string, any> = {
      name,
      source: 'ps', // manual adds default to 'ps'
    };
    if (this.form.disposition !== undefined) payload.disposition = this.form.disposition;
    if (this.form.method !== undefined) payload.method = this.form.method;
    if (isNum(this.form.pl_orbper)) payload.pl_orbper = Number(this.form.pl_orbper);
    if (isNum(this.form.pl_rade))   payload.pl_rade = Number(this.form.pl_rade);

    await this.svc.upsertOne(payload);
    this.form = {};
    await this.reload();
  }

  async delete(id: string) {
    if (!confirm(`Delete ${id}?`)) return;
    await this.svc.deleteOne(id);
    await this.reload();
  }

  async nukeAll() {
    if (!confirm('This will permanently delete ALL planets. Continue?')) return;
    await this.svc.deleteAll();
    await this.reload();
  }

  clear() {
    this.search = '';
    this.disposition = null;
    this.method = null;
    this.reload();
  }

  // ---------- Template helpers ----------
  fmtNum(x: number | null | undefined) {
    return (typeof x === 'number' && Number.isFinite(x))
      ? (x >= 100 ? Math.round(x) : +x.toFixed(3))
      : '—';
  }

  getPeriod(p: Planet): number | null {
    // Avoid "as any" in templates — do it here in TS
    const anyP = p as Record<string, any>;
    return (isNum(p.pl_orbper) ? p.pl_orbper! : (isNum(anyP['koi_period']) ? anyP['koi_period'] : null));
  }

  getRadius(p: Planet): number | null {
    const anyP = p as Record<string, any>;
    return (isNum(p.pl_rade) ? p.pl_rade! : (isNum(anyP['koi_prad']) ? anyP['koi_prad'] : null));
  }

  /** ECharts base options with log axes + nice tooltip */
  private baseChart(seriesData: any[]) {
    return {
      xAxis: { 
        type: 'log', 
        name: 'Period (days)', 
        nameGap: 20,
        nameTextStyle: {
          color: '#ffffff',
          fontSize: 12
        },
        axisLabel: {
          color: '#ffffff',
          fontSize: 12
        },
        axisLine: {
          lineStyle: {
            color: 'rgba(255, 255, 255, 0.3)'
          }
        },
        splitLine: {
          lineStyle: {
            color: 'rgba(255, 255, 255, 0.1)'
          }
        }
      },
      yAxis: { 
        type: 'log', 
        name: 'Radius (R⊕)', 
        nameGap: 16,
        nameTextStyle: {
          color: '#ffffff',
          fontSize: 12
        },
        axisLabel: {
          color: '#ffffff',
          fontSize: 12
        },
        axisLine: {
          lineStyle: {
            color: 'rgba(255, 255, 255, 0.3)'
          }
        },
        splitLine: {
          lineStyle: {
            color: 'rgba(255, 255, 255, 0.1)'
          }
        }
      },
      tooltip: {
        trigger: 'item',
        backgroundColor: 'rgba(15, 23, 42, 0.9)',
        borderColor: 'rgba(255, 255, 255, 0.1)',
        textStyle: {
          color: '#ffffff'
        },
        formatter: (p: any) => {
          const [x, y] = p.value;
          return `${p.name}<br/>P: ${Number(x).toPrecision(4)} d<br/>Rₚ: ${Number(y).toPrecision(4)} R⊕`;
        }
      },
      series: [{ 
        type: 'scatter', 
        symbolSize: 7, 
        data: seriesData,
        itemStyle: {
          borderColor: 'rgba(255, 255, 255, 0.5)'
        }
      }]
    };
  }

  private updateChartForRows(rows: Planet[]) {
    const pts = rows
      .map(r => {
        const x = this.getPeriod(r);
        const y = this.getRadius(r);
        return (isNum(x) && isNum(y)) ? { x: x as number, y: y as number, name: r.name || r.id } : null;
      })
      .filter(Boolean) as { x:number; y:number; name:string }[];

    const p95 = percentile(pts.map(p => p.y), 0.95);
    const data = pts.map(p => ({
      value: [p.x, p.y],
      name: p.name,
      itemStyle: p.y >= p95
        ? { color: '#ff6b6b', opacity: 0.95 }
        : { color: '#8ab4f8', opacity: 0.85 }
    }));

    this.chartOptions = this.baseChart(data);
  }
}

// helpers
function isNum(v: any): v is number { return typeof v === 'number' && Number.isFinite(v); }
function percentile(xs: number[], p: number) {
  if (!xs.length) return NaN;
  const s = xs.slice().sort((a,b)=>a-b);
  const idx = Math.floor((s.length - 1) * p);
  return s[idx];
}
