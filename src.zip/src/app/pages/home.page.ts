import { Component, OnInit, inject } from '@angular/core';
import { PlanetService } from '../services/planet.service';
import { MatCardModule } from '@angular/material/card';
import { NgIf } from '@angular/common';

@Component({
  standalone: true,
  selector: 'app-home',
  imports: [MatCardModule, NgIf],
  template: `
  <div class="grid" *ngIf="ready">
    <mat-card class="card-glass" style="grid-column: span 2;">
      <h1 style="margin:0 0 8px">Explore Worlds Beyond</h1>
      <p>Interactive, data-driven exoplanet playground powered by Angular + Firebase.</p>
    </mat-card>

    <mat-card class="card-glass kpi">
      <div class="knum">{{ counts?.total ?? '—' }}</div>
      <div class="klabel">Planets in DB</div>
    </mat-card>

    <mat-card class="card-glass">
      <div class="knum">128K</div>
      <div class="klabel">Max Context (model-ready)</div>
    </mat-card>
  </div>
  `,
  styles: [`
    .grid { display: grid; gap: 16px; grid-template-columns: repeat(2, minmax(0, 1fr)); }
    .kpi { display:flex; align-items:center; justify-content: center; flex-direction:column; padding: 24px; }
    .knum { font-size: 42px; font-weight: 700; }
    .klabel { opacity: .8; }
    @media (min-width: 900px) { .grid { grid-template-columns: repeat(3, 1fr); } }
  `]
})
export class HomePage implements OnInit {
  counts: { total: number } | null = null;
  ready = false;
  private planets = inject(PlanetService);

  async ngOnInit() {
    this.counts = await this.planets.getCounts();
    this.ready = true;
  }
}
