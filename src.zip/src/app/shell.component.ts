import { Component, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';

declare const require: any;

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    RouterOutlet, 
    RouterLink, 
    MatToolbarModule, 
    MatButtonModule, 
    MatIconModule
  ],
  template: `
  <!-- Video Background with Manual Play -->
  <div class="video-background">
    <video #videoPlayer class="video" playsinline>
      <source src="assets/vid/2381-157901992_tiny.mp4" type="video/mp4">
      Your browser does not support the video tag.
    </video>
    <div class="overlay"></div>
  </div>
  
  <div class="starfield"></div>
  <mat-toolbar color="primary" class="toolbar">
    <div class="logo-container" routerLink="/">
      <img [src]="logoPath" alt="Logo" class="logo">
      <!-- <span class="app-name">ExoPlayground</span> -->
    </div>
    <span class="spacer"></span>
    <a mat-button routerLink="/explore">Explore</a>
    <a mat-button routerLink="/upload">Upload</a>
  </mat-toolbar>
  <div class="container">
    <router-outlet/>
  </div>
  `,
  styles: [`n    :host {
      display: block;
      min-height: 100vh;
      position: relative;
      background: transparent;
    }
    
    .video-background {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: -10;
      overflow: hidden;
    }
    
    .video {
      position: absolute;
      top: 50%;
      left: 50%;
      min-width: 100%;
      min-height: 100%;
      width: auto;
      height: auto;
      transform: translate(-50%, -50%);
      object-fit: cover;
      object-position: center;
    }
    
    .overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0); /* Reduced opacity from 0.6 to 0.4 for a brighter video */
      backdrop-filter: blur(1px); /* Reduced blur for better video clarity */
    }

    .toolbar { 
      position: sticky; 
      top: 0; 
      z-index: 10;
      background: rgba(15, 23, 42, 0.8) !important;
      backdrop-filter: blur(10px);
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    .spacer { flex: 1; }
    .logo-container {
      display: flex;
      align-items: center;
      cursor: pointer;
      text-decoration: none;
      color: white;
      padding: 8px 0;
    }
    .logo {
      height: 50px;
      width: 150px;
      max-width: 200px;
      border-radius: 4px;
    }
    .app-name {
      font-weight: 700;
      font-size: 1.2rem;
    }
    .container { 
      padding: 24px; 
      position: relative; 
      z-index: 1;
      background: transparent;
      min-height: calc(100vh - 64px); /* Account for toolbar height */
    }
  `]
})
export class ShellComponent implements AfterViewInit {
  @ViewChild('videoPlayer') videoPlayer!: ElementRef<HTMLVideoElement>;

  ngAfterViewInit() {
    // Ensure video plays when component initializes
    const video = this.videoPlayer.nativeElement;
    
    // Set video attributes programmatically for better control
    video.muted = true;
    video.loop = true;
    video.playsInline = true;
    video.playbackRate = 1.0; // Normal playback speed
    
    // Handle video play promise
    const playPromise = video.play();
    
    // Handle autoplay restrictions
    if (playPromise !== undefined) {
      playPromise.catch(error => {
        console.log('Autoplay prevented:', error);
        // Show play button or handle the error
      });
    }
  }
  logoPath = window.location.origin + '/assets/images/logo2.png';
}
