import { Injectable } from '@angular/core';

const BUCKET = 'exoplanet-hackathon.appspot.com'; // your bucket

@Injectable({ providedIn: 'root' })
export class SnapshotService {
  // returns an array of plain docs { id, name, ... }
  async fetchLatest(): Promise<any[]> {
    // fetch manifest
    const manifestURL = `https://firebasestorage.googleapis.com/v0/b/${BUCKET}/o/${encodeURIComponent('snapshots/manifest.json')}?alt=media`;
    const m = await fetch(manifestURL, { cache: 'no-store' });
    if (!m.ok) throw new Error('Snapshot manifest not found.');
    const { latest } = await m.json();
    if (!latest) throw new Error('Snapshot path missing in manifest.');

    // fetch NDJSON snapshot
    const snapURL = `https://firebasestorage.googleapis.com/v0/b/${BUCKET}/o/${encodeURIComponent(latest)}?alt=media`;
    const resp = await fetch(snapURL, { cache: 'no-store' });
    if (!resp.ok) throw new Error('Snapshot download failed.');
    const text = await resp.text();
    // parse NDJSON safely
    const rows: any[] = [];
    for (const line of text.split('\n')) {
      if (!line.trim()) continue;
      try { rows.push(JSON.parse(line)); } catch {}
    }
    return rows;
  }
}
