// src/app/services/data-store.service.ts
import { Injectable, inject, signal, computed, effect } from '@angular/core';
import { PlanetService } from './planet.service';
import type { Planet } from '../models/planet';

type Range = [number, number];

@Injectable({ providedIn: 'root' })
export class DataStoreService {
  private planetsSvc = inject(PlanetService);

  // Raw data
  planets = signal<Planet[]>([]);
  loading = signal<boolean>(true);

  // Filters
  disposition = signal<string>('');                // '', 'CONFIRMED', 'CANDIDATE', 'FALSE POSITIVE'
  method = signal<string>('');                     // discovery method
  yearRange = signal<Range>([1990, new Date().getFullYear()]);
  periodRange = signal<Range>([0.1, 1000]);        // days
  radiusRange = signal<Range>([0.1, 20]);          // Earth radii
  search = signal<string>('');                     // name contains

  // Derived lists
  methods = computed(() => {
    const set = new Set(this.planets().map(p => p.method).filter(Boolean) as string[]);
    return Array.from(set).sort();
  });

  years = computed(() => {
    const ys = this.planets().map(p => p.disc_year).filter((x): x is number => Number.isFinite(x as any));
    return ys.length ? [Math.min(...ys), Math.max(...ys)] as Range
                     : [1990, new Date().getFullYear()] as Range;
  });

  // Filtered data
  filtered = computed(() => {
    const q = this.search().toLowerCase();
    const [y0, y1] = this.yearRange();
    const [p0, p1] = this.periodRange();
    const [r0, r1] = this.radiusRange();
    const disp = this.disposition();
    const meth = this.method();

    return this.planets().filter(p => {
      if (disp && p.disposition !== disp) return false;
      if (meth && p.method !== meth) return false;
      if (p.disc_year && (p.disc_year < y0 || p.disc_year > y1)) return false;

      const period = (p.pl_orbper ?? p.koi_period);
      if (typeof period === 'number' && (period < p0 || period > p1)) return false;

      // koi_prad may exist on your model/importer; if not, pl_rade is used.
      const rad = (p.pl_rade ?? (p as any).koi_prad ?? null);
      if (typeof rad === 'number' && (rad < r0 || rad > r1)) return false;

      if (q && !((p.name || p.id).toLowerCase().includes(q))) return false;

      return true;
    });
  });

  // KPIs
  kpi = computed(() => {
    const rows = this.filtered();
    const total = rows.length;

    const confirmed = rows.filter(r => r.disposition === 'CONFIRMED').length;
    const candidate = rows.filter(r => r.disposition === 'CANDIDATE').length;
    const fp        = rows.filter(r => r.disposition === 'FALSE POSITIVE').length;

    const pickPrad = (r: Planet) => r.pl_rade ?? (r as any).koi_prad ?? null;
    const pickPeriod = (r: Planet) => r.pl_orbper ?? r.koi_period ?? null;

    // medians
    const radii = rows.map(pickPrad).filter(isNum);
    const peri  = rows.map(pickPeriod).filter(isNum);
    const med = (xs: number[]) => xs.length ? xs.slice().sort((a,b)=>a-b)[Math.floor(xs.length/2)] : null;

    return { total, confirmed, candidate, fp, medRadius: med(radii), medPeriod: med(peri) };
  });

  // Chart datasets
  scatterRadiusPeriod = computed(() => {
    return this.filtered()
      .map(r => {
        const x = (r.pl_orbper ?? r.koi_period ?? null);
        const y = (r.pl_rade ?? (r as any).koi_prad ?? null);
        if (!isNum(x) || !isNum(y)) return null;
        return { value: [x, y], name: r.name || r.id, itemStyle: { opacity: 0.85 } };
      })
      .filter(Boolean) as any[];
  });

  pieByDisposition = computed(() => {
    const g: Record<string, number> = {};
    this.filtered().forEach(r => {
      const k = r.disposition || '—';
      g[k] = (g[k] || 0) + 1;
    });
    return Object.entries(g).map(([name, value]) => ({ name, value })).sort((a,b)=>b.value-a.value);
  });

  barByYearMethod = computed(() => {
    // stacked bar: year -> method counts
    const rows = this.filtered();
    const years = new Set<number>(); const methods = new Set<string>();
    const map = new Map<string, number>(); // key: `${year}|${method}`

    rows.forEach(r => {
      const y = r.disc_year ?? 0; if (!y) return;
      years.add(y);
      const m = r.method || '—'; methods.add(m);
      const key = `${y}|${m}`;
      map.set(key, (map.get(key) || 0) + 1);
    });

    const xs = Array.from(years).sort((a,b)=>a-b);
    const ms = Array.from(methods).sort();

    const series = ms.map(m => ({
      name: m,
      type: 'bar',
      stack: 'total',
      emphasis: { focus: 'series' },
      data: xs.map(y => map.get(`${y}|${m}`) || 0)
    }));

    return { years: xs, series };
  });

  constructor() {
    this.load();
    // Auto-sync year slider to available years
    effect(() => {
      const [minY, maxY] = this.years();
      const [curMin, curMax] = this.yearRange();
      if (curMin < minY || curMax > maxY) this.yearRange.set([minY, maxY]);
    });
  }

  async load() {
    this.loading.set(true);
    try {
      // Pull up to a few thousand docs for the playground charts
      const res: any = await this.planetsSvc.page({ pageSize: 2000 });

      // Accept both shapes: Array<Planet> OR { rows: Planet[], last: ... }
      let rows: Planet[] = Array.isArray(res) ? res : (res?.rows ?? []);

      if (!rows.length) rows = SAMPLE_FALLBACK; // graceful local fallback

      // Normalize display name
      rows = rows.map(r => ({ ...r, name: r.name || r.id }));
      this.planets.set(rows);
    } finally {
      this.loading.set(false);
    }
  }
}

function isNum(x: any): x is number { return typeof x === 'number' && Number.isFinite(x); }

// --- tiny local fallback sample (edit/extend freely) ---
const SAMPLE_FALLBACK: Planet[] = [
  { id: 'Kepler-22_b', name: 'Kepler-22 b', source:'ps', disposition:'CONFIRMED', method:'Transit', disc_year:2011, pl_orbper:289.86, pl_rade:2.38, st_teff:5518, st_rad:0.979 },
  { id: 'Kepler-452_b', name: 'Kepler-452 b', source:'ps', disposition:'CONFIRMED', method:'Transit', disc_year:2015, pl_orbper:384.84, pl_rade:1.63, st_teff:5757, st_rad:1.11 },
  { id: 'TOI-700_d',  name: 'TOI-700 d',  source:'ps', disposition:'CONFIRMED', method:'Transit', disc_year:2020, pl_orbper:37.426, pl_rade:1.19, st_teff:3480, st_rad:0.42 },
  { id: 'KOI-123',    name: 'KOI-123',    source:'koi', disposition:'CANDIDATE', method:'Transit', disc_year:2014, koi_period:12.1, ...( { koi_prad: 1.9 } as any) },
  { id: 'KOI-999',    name: 'KOI-999',    source:'koi', disposition:'FALSE POSITIVE', method:'Transit', disc_year:2013, koi_period:3.1, ...( { koi_prad: 0.9 } as any) }
];
