import { Injectable } from '@angular/core';
import {
  Firestore, collection, query, where, orderBy, limit, startAfter,
  getDocs, getDoc, doc, setDoc, deleteDoc,
  QueryDocumentSnapshot, DocumentData, CollectionReference,
  getCountFromServer
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import type { Planet, Disposition } from '../models/planet';

export type PageOpts = {
  pageSize: number;
  last?: QueryDocumentSnapshot<DocumentData> | undefined;
  disposition?: string | null;
  method?: string | null;
  search?: string | null;
};

@Injectable({ providedIn: 'root' })
export class PlanetService {
  private fs: Firestore = db;
  private coll: CollectionReference = collection(this.fs, 'planets');

  // ---------- Write queue with gentle throttling (prevents quota spikes) ----------
  private writeQueue = Promise.resolve();
  private async enqueue<T>(fn: () => Promise<T>, delayMs = 120): Promise<T> {
    this.writeQueue = this.writeQueue.then(async () => {
      try {
        const out = await fn();
        await new Promise(r => setTimeout(r, delayMs)); // small delay
        return out as any;
      } catch (e: any) {
        if (e?.code === 'resource-exhausted') {
          throw new Error('Firestore quota exceeded. Try again in a minute or reduce write rate.');
        }
        throw e;
      }
    });
    return this.writeQueue as Promise<T>;
  }

  // -------------------------------- READS --------------------------------
  async page(opts: PageOpts): Promise<{ rows: Planet[]; last?: QueryDocumentSnapshot<DocumentData> }> {
    const size = Math.min(50, Math.max(5, opts.pageSize));
    const token = (opts.search || '').trim().toLowerCase();
    const hasSearch = !!token;
    const hasDisposition = !!opts.disposition;
    const hasMethod = !!opts.method;

    let qRef;
    if (hasSearch) {
      // Index-free search: array-contains without orderBy; no cursor pagination.
      qRef = query(this.coll, where('nameSearch', 'array-contains', token), limit(size));
    } else if (hasDisposition) {
      qRef = query(
        this.coll,
        where('disposition', '==', opts.disposition),
        orderBy('name'),
        limit(size),
        ...(opts.last ? [startAfter(opts.last)] : [])
      );
    } else if (hasMethod) {
      qRef = query(
        this.coll,
        where('method', '==', opts.method),
        orderBy('name'),
        limit(size),
        ...(opts.last ? [startAfter(opts.last)] : [])
      );
    } else {
      qRef = query(this.coll, orderBy('name'), limit(size), ...(opts.last ? [startAfter(opts.last)] : []));
    }

    const snap = await getDocs(qRef);
    let rows = snap.docs.map(d => ({ id: d.id, ...(d.data() as any) })) as Planet[];

    // Optional client-side refine when using index-free search
    if (hasSearch) {
      if (hasDisposition) rows = rows.filter(r => (r.disposition || '') === opts.disposition);
      if (hasMethod) rows = rows.filter(r => (r.method || '') === opts.method);
    }

    const last = snap.docs[snap.docs.length - 1];
    return { rows, last };
  }

  async getOne(id: string): Promise<Planet | null> {
    const ref = doc(this.fs, 'planets', id);
    const snap = await getDoc(ref);
    return snap.exists() ? ({ id: snap.id, ...(snap.data() as any) } as Planet) : null;
  }

  /** Fast counts using Firestore aggregate queries (no composite indexes needed for single-field equality). */
  async getCounts(): Promise<{ total: number; confirmed: number; candidate: number; fp: number }> {
    const total = (await getCountFromServer(this.coll)).data().count;

    const confirmed = (await getCountFromServer(query(this.coll, where('disposition', '==', 'CONFIRMED')))).data().count;
    const candidate = (await getCountFromServer(query(this.coll, where('disposition', '==', 'CANDIDATE')))).data().count;
    const fp        = (await getCountFromServer(query(this.coll, where('disposition', '==', 'FALSE POSITIVE')))).data().count;

    return { total, confirmed, candidate, fp };
  }

  // -------------------------------- WRITES --------------------------------
  /** Create or update a single planet. `name` is required; other fields are optional. */
  upsertOne(input: Partial<Planet> & { id?: string; name?: string | null }) {
    const name = (input.name ?? '').toString().trim();
    if (!name) return Promise.reject(new Error('Name is required'));

    const id = (input.id ?? name)
      .toString().trim()
      .replace(/\s+/g, '_')
      .replace(/[^\w.-]/g, '_');

    const data: Partial<Planet> = {
      ...input,
      id: undefined,            // don't persist id as a field
      name,
      nameSearch: tokenise(name),
    };

    const ref = doc(this.fs, 'planets', id);
    return this.enqueue(() => setDoc(ref, data, { merge: true }));
  }

  deleteOne(id: string) {
    const ref = doc(this.fs, 'planets', id);
    return this.enqueue(() => deleteDoc(ref));
  }

  /** Danger: deletes all documents in pages (serialized to avoid quota spikes). */
  async deleteAll(batchSize = 200, delayMs = 200) {
    while (true) {
      const snap = await getDocs(query(this.coll, limit(batchSize)));
      if (snap.empty) break;
      for (const d of snap.docs) {
        await this.enqueue(() => deleteDoc(d.ref), delayMs);
      }
    }
  }
}

function tokenise(name: string) {
  return name.toLowerCase().split(/[^\w]+/).filter(Boolean);
}
