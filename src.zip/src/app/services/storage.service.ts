import { Injectable } from '@angular/core';
import { storage } from '../lib/firebase';
import { ref, uploadBytesResumable, UploadTaskSnapshot } from 'firebase/storage';

@Injectable({ providedIn: 'root' })
export class StorageService {
  uploadFileResumable(path: string, file: File, onProgress: (pct:number)=>void) {
    const r = ref(storage, path);
    const task = uploadBytesResumable(r, file, { contentType: 'text/csv' });
    return new Promise<UploadTaskSnapshot>((resolve, reject) => {
      task.on('state_changed', snap => {
        const pct = (snap.bytesTransferred / snap.totalBytes) * 100;
        onProgress(Math.round(pct));
      }, reject, () => resolve(task.snapshot));
    });
  }
}
