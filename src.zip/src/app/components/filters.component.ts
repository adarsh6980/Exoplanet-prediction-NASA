import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { NgFor } from '@angular/common';
import { DataStoreService } from '../services/data-store.service';

@Component({
  selector: 'filters-panel',
  standalone: true,
  imports: [
    FormsModule, MatCardModule, MatFormFieldModule, MatInputModule, MatSelectModule,
    MatButtonModule, MatIconModule, NgFor
  ],
  template: `
  <mat-card class="card-glass panel filters-container">
    <h3 class="filters-header">Filters</h3>

    <mat-form-field appearance="fill">
      <mat-label>Search name</mat-label>
      <input matInput
             [ngModel]="store.search()"
             (ngModelChange)="store.search.set($event)">
    </mat-form-field>

    <mat-form-field appearance="fill">
      <mat-label>Disposition</mat-label>
      <mat-select
        [ngModel]="store.disposition()"
        (ngModelChange)="store.disposition.set($event)">
        <mat-option [value]="''">Any</mat-option>
        <mat-option value="CONFIRMED">Confirmed</mat-option>
        <mat-option value="CANDIDATE">Candidate</mat-option>
        <mat-option value="FALSE POSITIVE">False positive</mat-option>
      </mat-select>
    </mat-form-field>

    <mat-form-field appearance="fill">
      <mat-label>Discovery method</mat-label>
      <mat-select
        [ngModel]="store.method()"
        (ngModelChange)="store.method.set($event)">
        <mat-option [value]="''">Any</mat-option>
        <mat-option *ngFor="let m of store.methods()" [value]="m">{{ m }}</mat-option>
      </mat-select>
    </mat-form-field>

    <!-- Year range -->
    <div class="row">
      <mat-form-field appearance="fill">
        <mat-label>Year min</mat-label>
        <input matInput type="number"
               [ngModel]="store.yearRange()[0]"
               (ngModelChange)="setYearMin($event)">
      </mat-form-field>
      <mat-form-field appearance="fill">
        <mat-label>Year max</mat-label>
        <input matInput type="number"
               [ngModel]="store.yearRange()[1]"
               (ngModelChange)="setYearMax($event)">
      </mat-form-field>
    </div>

    <!-- Period range -->
    <div class="row">
      <mat-form-field appearance="fill">
        <mat-label>Period min</mat-label>
        <input matInput type="number" step="0.1"
               [ngModel]="store.periodRange()[0]"
               (ngModelChange)="setPeriodMin($event)">
      </mat-form-field>
      <mat-form-field appearance="fill">
        <mat-label>Period max</mat-label>
        <input matInput type="number" step="0.1"
               [ngModel]="store.periodRange()[1]"
               (ngModelChange)="setPeriodMax($event)">
      </mat-form-field>
    </div>

    <!-- Radius range -->
    <div class="row">
      <mat-form-field appearance="fill">
        <mat-label>Radius min</mat-label>
        <input matInput type="number" step="0.1"
               [ngModel]="store.radiusRange()[0]"
               (ngModelChange)="setRadiusMin($event)">
      </mat-form-field>
      <mat-form-field appearance="fill">
        <mat-label>Radius max</mat-label>
        <input matInput type="number" step="0.1"
               [ngModel]="store.radiusRange()[1]"
               (ngModelChange)="setRadiusMax($event)">
      </mat-form-field>
    </div>

    <div class="button-container">
      <button mat-stroked-button (click)="reset()" class="action-button">
        <mat-icon>refresh</mat-icon>
        <span>Reset Filters</span>
      </button>
    </div>
  </mat-card>
  `,
  styles: [`
    .button-container {
      display: flex;
      justify-content: center;
      margin: 16px 0;
      
      .action-button {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 0 16px;
        height: 36px;
        border-radius: 18px;
        font-size: 14px;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        transition: all 0.2s ease;
        background: rgba(30, 41, 59, 0.8) !important;
        color: rgba(255, 255, 255, 0.9) !important;
        border: 1px solid rgba(255, 255, 255, 0.2) !important;
        
        mat-icon {
          font-size: 18px;
          width: 18px;
          height: 18px;
          margin-right: 4px;
        }
        
        &:hover {
          background: rgba(51, 65, 85, 0.9) !important;
          transform: translateY(-1px);
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
        }
        
        &:active {
          transform: translateY(0);
          box-shadow: none;
        }
      }
    }
    
    .filters-container {
      padding: 16px;
      height: 100%;
      box-sizing: border-box;
      display: flex;
      flex-direction: column;
      background: transparent !important;
      height: 100%;
    }
    
    .filters-header {
      font-size: var(--font-size-lg);
      font-weight: var(--font-weight-semibold);
      color: var(--fg);
      margin: 0 0 var(--spacing-md) 0;
      padding-bottom: var(--spacing-sm);
      border-bottom: 1px solid var(--glass-border);
    }
    
    .panel {
      position: sticky;
      top: var(--spacing-md);
      height: fit-content;
      max-height: calc(100vh - 32px);
      overflow-y: auto;
      padding: var(--spacing-md) !important;
    }
    
    /* Update form field styles for consistency */
    ::ng-deep .mat-mdc-form-field {
      width: 100%;
      margin-bottom: var(--spacing-sm);
    }
    
    ::ng-deep .mat-mdc-form-field-label {
      color: var(--muted) !important;
      font-size: var(--font-size-sm);
    }
    
    ::ng-deep .mat-mdc-select-value-text,
    ::ng-deep .mat-mdc-select-arrow {
      color: var(--fg);
      font-size: var(--font-size-base);
    }
    
    ::ng-deep .mat-mdc-form-field-infix {
      min-height: 44px;
      display: flex;
      align-items: center;
    }
    
    ::ng-deep .mat-mdc-text-field-wrapper {
      background: rgba(255, 255, 255, 0.05) !important;
      border-radius: 8px !important;
    }
    .row { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
  `]
})
export class FiltersComponent {
  store = inject(DataStoreService);

  private clampRange([min, max]: [number, number], low: number, high: number): [number, number] {
    return [Math.max(low, Math.min(min, high)), Math.max(low, Math.min(max, high))];
  }

  setYearMin(v: any) {
    const [min, maxAvail] = this.store.years();
    const [_, curMax] = this.store.yearRange();
    const next: [number, number] = [Number(v) || min, curMax || maxAvail];
    this.store.yearRange.set(this.clampRange(next, min, maxAvail));
  }
  setYearMax(v: any) {
    const [min, maxAvail] = this.store.years();
    const [curMin, _] = this.store.yearRange();
    const next: [number, number] = [curMin || min, Number(v) || maxAvail];
    this.store.yearRange.set(this.clampRange(next, min, maxAvail));
  }

  setPeriodMin(v: any) {
    const [curMin, curMax] = this.store.periodRange();
    this.store.periodRange.set([toNum(v, 0.1), curMax]);
  }
  setPeriodMax(v: any) {
    const [curMin, _] = this.store.periodRange();
    this.store.periodRange.set([curMin, toNum(v, 1000)]);
  }

  setRadiusMin(v: any) {
    const [curMin, curMax] = this.store.radiusRange();
    this.store.radiusRange.set([toNum(v, 0.1), curMax]);
  }
  setRadiusMax(v: any) {
    const [curMin, _] = this.store.radiusRange();
    this.store.radiusRange.set([curMin, toNum(v, 20)]);
  }

  reset() {
    this.store.disposition.set('');
    this.store.method.set('');
    this.store.search.set('');
    this.store.yearRange.set(this.store.years());
    this.store.periodRange.set([0.1, 1000]);
    this.store.radiusRange.set([0.1, 20]);
  }
}

function toNum(v: any, fallback: number): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}
