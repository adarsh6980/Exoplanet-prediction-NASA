import { Component, Input } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { NgIf } from '@angular/common';

@Component({
  selector: 'kpi-card',
  standalone: true,
  imports: [MatCardModule, NgIf],
  template: `
  <mat-card class="kpi card-glass">
    <div class="label">{{ label }}</div>
    <div class="value">{{ value }}</div>
    <div class="sub" *ngIf="sub">{{ sub }}</div>
  </mat-card>
  `,
  styles: [`
    .kpi { 
      padding: var(--spacing-lg) var(--spacing-xl);
      background: transparent !important;
      height: 100%;
      box-sizing: border-box;
    }
    .kpi:hover {
      background: rgba(255, 255, 255, 0.03) !important;
      transform: translateY(-2px) !important;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1) !important;
      transition: all var(--transition-normal);
    }
    .label { 
      color: var(--fg);
      opacity: 0.9;
      font-size: var(--font-size-base);
      font-weight: var(--font-weight-medium);
      letter-spacing: 0.3px;
      margin-bottom: var(--spacing-xs);
    }
    .value { 
      font-size: var(--font-size-3xl);
      font-weight: var(--font-weight-bold);
      color: var(--fg);
      margin: var(--spacing-xs) 0;
      line-height: 1.2;
      letter-spacing: -0.5px;
    }
    .sub { 
      color: var(--muted);
      font-size: var(--font-size-sm);
      margin-top: var(--spacing-xs);
      opacity: 0.9;
    }
  `]
})
export class KpiCardComponent {
  @Input() label = '';
  @Input() value: string | number = '—';
  @Input() sub = '';
}
