import { Component, Input } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { NgxEchartsModule } from 'ngx-echarts';

@Component({
  selector: 'chart-card',
  standalone: true,
  imports: [MatCardModule, NgxEchartsModule],
  template: `
  <mat-card class="card-glass">
    <div class="title">{{ title }}</div>
    <div echarts [options]="options" class="chart"></div>
  </mat-card>
  `,
  styles: [`
    :host {
      display: block;
      height: 100%;
    }
    .title { 
      font-weight: 600; 
      margin: 8px 12px 0; 
      color: rgba(255, 255, 255, 0.87);
    }
    .chart { 
      height: 320px;
      background: transparent !important;
    }
    /* Ensure all chart elements are transparent */
    ::ng-deep .chart *,
    ::ng-deep .echarts,
    ::ng-deep .echarts *,
    ::ng-deep .echarts canvas,
    ::ng-deep .echarts div,
    ::ng-deep .echarts-legend,
    ::ng-deep .echarts-axis,
    ::ng-deep .echarts-tooltip {
      background: transparent !important;
      background-color: transparent !important;
    }
    /* Disable any hover effects and tooltips */
    :host ::ng-deep *:hover {
      background: transparent !important;
      background-color: transparent !important;
    }
    /* Remove hover effects on series */
    :host ::ng-deep .echarts-series,
    :host ::ng-deep .echarts-mark-point,
    :host ::ng-deep .echarts-mark-line,
    :host ::ng-deep .echarts-mark-area {
      transition: none !important;
      pointer-events: none !important;
    }
    /* Make tooltip transparent */
    :host ::ng-deep .echarts-tooltip {
      background: rgba(0, 0, 0, 0.7) !important;
      border: none !important;
      box-shadow: none !important;
    }
  `]
})
export class ChartCardComponent {
  @Input() title = '';
  @Input() options: any = {};
}
