import { Component, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-video-background',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="video-background">
      <video #videoPlayer class="video" playsinline>
        <source src="assets/vid/2381-157901992_tiny.mp4" type="video/mp4">
        Your browser does not support the video tag.
      </video>
      <div class="overlay"></div>
    </div>
  `,
  styles: [`
    :host {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      z-index: -1;
      overflow: hidden;
      display: block;
    }
    
    .video-background {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      overflow: hidden;
    }
    
    .video {
      position: absolute;
      top: 50%;
      left: 50%;
      min-width: 100%;
      min-height: 100%;
      width: auto;
      height: auto;
      transform: translate(-50%, -50%);
      object-fit: cover;
      object-position: center;
    }
    
    .overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.4);
      backdrop-filter: blur(1px);
    }
  `]
})
export class VideoBackgroundComponent implements AfterViewInit {
  @ViewChild('videoPlayer') videoPlayer!: ElementRef<HTMLVideoElement>;

  ngAfterViewInit() {
    // Ensure video plays when component initializes
    const video = this.videoPlayer.nativeElement;
    
    // Set video attributes programmatically for better control
    video.muted = true;
    video.loop = true;
    video.playsInline = true;
    video.playbackRate = 0.5; // Slower playback speed (50% of normal speed)
    
    // Handle video play promise
    const playPromise = video.play();
    
    // Handle autoplay restrictions
    if (playPromise !== undefined) {
      playPromise.catch(error => {
        console.log('Autoplay prevented:', error);
        // Show play button or handle the error
      });
    }
  }}
