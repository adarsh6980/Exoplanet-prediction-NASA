import { Component, Input } from '@angular/core';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

export interface TableRow {
  id: string;
  name: string;
  source?: string;
  disposition?: string;
  period?: number | null;
  radius?: number | null;
  year?: number | null;
}

@Component({
  selector: 'planet-table',
  standalone: true,
  imports: [MatTableModule, MatButtonModule, MatIconModule],
  template: `
  <div class="header">
    <h3>Results ({{ rows.length }})</h3>
    <button mat-stroked-button (click)="download()" class="export-button">
      <mat-icon>download</mat-icon>
      <span>Export CSV</span>
    </button>
  </div>
  <div class="table-container">
    <table mat-table [dataSource]="rows" class="mat-elevation-z1">
    <ng-container matColumnDef="name">
      <th mat-header-cell *matHeaderCellDef>Name</th>
      <td mat-cell *matCellDef="let r">{{ r.name }}</td>
    </ng-container>
    <ng-container matColumnDef="disp">
      <th mat-header-cell *matHeaderCellDef>Disp.</th>
      <td mat-cell *matCellDef="let r">{{ r.disposition || '—' }}</td>
    </ng-container>
    <ng-container matColumnDef="period">
      <th mat-header-cell *matHeaderCellDef>Period</th>
      <td mat-cell *matCellDef="let r">{{ r.period ?? '—' }}</td>
    </ng-container>
    <ng-container matColumnDef="radius">
      <th mat-header-cell *matHeaderCellDef>Radius</th>
      <td mat-cell *matCellDef="let r">{{ r.radius ?? '—' }}</td>
    </ng-container>
      <tr mat-header-row *matHeaderRowDef="cols"></tr>
      <tr mat-row *matRowDef="let row; columns: cols;"></tr>
    </table>
  </div>
  `,
  styles: [`
    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin: 0 -8px 16px -8px;
      padding: 8px 8px 8px 0;
      
      h3 {
        margin: 0;
        color: rgba(255, 255, 255, 0.9);
        font-weight: 500;
      }
      
      .export-button {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 0 16px;
        height: 36px;
        border-radius: 18px;
        font-size: 14px;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        transition: all 0.2s ease;
        background: rgba(30, 41, 59, 0.8) !important;
        color: rgba(255, 255, 255, 0.9) !important;
        border: 1px solid rgba(255, 255, 255, 0.2) !important;
        
        mat-icon {
          font-size: 18px;
          width: 18px;
          height: 18px;
          margin-right: 4px;
        }
        
        &:hover {
          background: rgba(51, 65, 85, 0.9) !important;
          transform: translateY(-1px);
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
        }
        
        &:active {
          transform: translateY(0);
          box-shadow: none;
        }
      }
    }
    
    :host {
      display: flex;
      flex-direction: column;
      height: 100%;
      color: var(--fg);
    }

    .header { 
      display: flex; 
      align-items: center; 
      justify-content: space-between; 
      margin-bottom: var(--spacing-md);
      padding: 0 var(--spacing-md);
      flex-shrink: 0;
    }

    .header h3 {
      margin: 0;
      font-size: var(--font-size-lg);
      font-weight: var(--font-weight-semibold);
    }

    .table-container {
      flex: 1;
      overflow: auto;
      display: flex;
      flex-direction: column;
    }

    table {
      width: 100%;
      color: var(--fg);
      font-size: var(--font-size-sm);
    }

    th {
      font-weight: var(--font-weight-semibold);
      color: var(--fg);
      opacity: 0.9;
    }

    td {
      color: var(--fg);
      opacity: 0.9;
    }
    tr.mat-mdc-row {
      background-color: transparent !important;
    }
    tr.mat-mdc-row:hover {
      background-color: transparent !important;
    }
    .mat-mdc-table {
      background-color: transparent !important;
    }
    .mat-mdc-icon-button {
      color: #f44336 !important; /* Red color for delete icon */
      width: 32px;
      height: 32px;
      line-height: 32px;
      padding: 0;
    }
    
    .mat-mdc-icon-button:hover {
      background-color: rgba(244, 67, 54, 0.1); /* Light red background on hover */
    }
    
    .mat-mdc-icon-button .mat-icon {
      font-size: 20px;
      width: 20px;
      height: 20px;
      line-height: 20px;
    }
  `]
})
export class PlanetTableComponent {
  @Input() rows: TableRow[] = [];
  cols = ['name','disp','period','radius'];

  download() {
    const head = ['name','disposition','period','radius','year'];
    const lines = [head.join(',')].concat(
      this.rows.map(r => [
        q(r.name), q(r.disposition||''), n(r.period), n(r.radius), n(r.year)
      ].join(','))
    );
    const blob = new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob); const a = document.createElement('a');
    a.href = url; a.download = 'planets.csv'; a.click(); URL.revokeObjectURL(url);
    function q(s: string){ return `"${(s||'').replace(/"/g,'""')}"`; }
    function n(x: any){ return x==null ? '' : String(x); }
  }
}
