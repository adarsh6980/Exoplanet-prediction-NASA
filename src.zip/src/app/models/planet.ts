// Canonical Planet model used everywhere in the app

export type Disposition = 'CONFIRMED' | 'CANDIDATE' | 'FALSE POSITIVE';

export interface Planet {
  id: string;

  // core
  name?: string;                 // omit if unknown
  source?: 'koi' | 'ps';         // optional because old docs may not have it
  disposition?: Disposition;
  method?: string;
  disc_year?: number;

  // KOI fields
  koi_period?: number;
  koi_prad?: number;
  koi_duration?: number;
  koi_depth?: number;
  koi_teq?: number;
  koi_insol?: number;
  koi_srad?: number;

  // Planetary Systems fields
  pl_orbper?: number;
  pl_rade?: number;
  pl_bmasse?: number;

  // Stellar
  st_teff?: number;
  st_rad?: number;
  st_mass?: number;

  // search helpers
  nameSearch?: string[];
}
