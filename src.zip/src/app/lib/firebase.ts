// src/app/lib/firebase.ts
import { getApps, getApp, initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import {
  initializeFirestore,
  persistentLocalCache,
  persistentMultipleTabManager,
} from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import { environment } from '../../environments/environment';

export const firebaseApp =
  getApps().length ? getApp() : initializeApp(environment.firebase);

// Firestore: avoid streaming being blocked by extensions/proxies
export const db = initializeFirestore(firebaseApp, {
  ignoreUndefinedProperties: true,
  // Pick ONE of the two lines below:

  experimentalAutoDetectLongPolling: true, // let SDK decide when to use long-polling
  // experimentalForceLongPolling: true,   // uncomment to always force long-polling

  // Nice-to-have local cache (keeps reads snappy)
  localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }),
});

export const storage = getStorage(firebaseApp, 'gs://exoplanet-hackathon.appspot.com');
export const auth = getAuth(firebaseApp);
