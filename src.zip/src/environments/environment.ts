export const environment = {
  production: false,
  firebase: {
    apiKey: 'AIzaSyCTL84HGbyiKltbrR3gHd9tU5-oHc2hUD0',
    authDomain: 'exoplanet-hackathon.firebaseapp.com',
    projectId: 'exoplanet-hackathon',
    storageBucket: 'exoplanet-hackathon.appspot.com',
    messagingSenderId: '332229054507',
    appId: '1:332229054507:web:5a25b7e287cfd1b54c1a6e',
  },
  // (optional) a list of admin emails for importer access
  adminEmails: ['you@example.com']
};
